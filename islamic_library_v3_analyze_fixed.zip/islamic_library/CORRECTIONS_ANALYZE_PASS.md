# إصلاحات ما بعد `flutter analyze` الفعلي

هذه كل الأخطاء والتحذيرات التي أرسلتها من `flutter analyze` الحقيقي على
جهازك، وما صُحِّح لكل واحد منها بالضبط.

## أخطاء (errors) — كانت ستمنع التجميع

| الملف | المشكلة | الإصلاح |
|---|---|---|
| `pdf_text_extractor.dart:62` | `pageText.fullText` بدون فحص null | `PdfPageText?` فعليًا قابلة لـ null — أصبحت `(pageText?.fullText ?? '').trim()`. هذا أيضًا **يؤكد** أن `.fullText` كان الاسم الصحيح فعلًا، المشكلة كانت في الـ nullability فقط |
| `reader_screen.dart:101` | `await` على دالة `void` | `startTextSearch()` دالة متزامنة وليست `Future` — أُزيلت `await` |
| `reader_screen.dart:202` | تمرير `int?` لمعامل يطلب `int` | `_addBookmark` أصبحت تفحص `pageNumber` صراحة قبل الاستخدام |
| `reader_screen.dart:240,247` | عمليات حسابية على قيمة قابلة لـ null | `_ReaderBottomBar` أصبح يفحص `currentPage == null` قبل `±1` |
| `test/widget_test.dart:16` | إشارة لكلاس `MyApp` غير موجود | استبدلته بملف اختبار مطابق للاسم الحقيقي `IslamicLibraryApp` |

## تحذيرات (warnings)

| الملف | المشكلة | الإصلاح |
|---|---|---|
| `app/router.dart` | استيراد `material.dart` غير مستخدم | حُذف |
| `content_import_service.dart:159` | `!` غير ضرورية (النوع مُروَّج أصلًا) | حُذفت |
| `library_screen.dart` | كلاس `_DownloadsPlaceholderTab` غير مستخدم بعد استبداله بـ `DownloadsScreen` الحقيقية | حُذف بالكامل |
| `theme_provider.dart` | استيراد `flutter_riverpod.dart` مكرر مع `legacy.dart` | أُبقي `legacy.dart` فقط |

## ملاحظات (info) — لا تمنع التجميع لكن صُحِّحت للنظافة

| الملف | المشكلة | الإصلاح |
|---|---|---|
| `content_seed_models.dart`, `entities.dart` | Dangling library doc comment | أُضيف `library;` بعد تعليق التوثيق العلوي في كل ملف |
| `user_library_tables.dart:67` | `<id>` في تعليق يُفسَّر كـ HTML | استُبدل بـ `` `section:id` `` بين backticks |
| `settings_screen.dart` (6 مواضع) | `RadioListTile.groupValue/onChanged` مهجورة منذ Flutter 3.32 | أُعيد بناء قسم اختيار المظهر بالكامل باستخدام `RadioGroup<ThemeMode>` الجديد — تحققت من التوقيع الدقيق لهذا الودجت من `api.flutter.dev` مباشرة قبل التطبيق |

## خلاصة

كل الأخطاء الفعلية كانت من فئتين فقط:
1. **Nullability حقيقية** في pdfrx (`pageNumber`, نتيجة `loadText()`) لم
   تكن واضحة من التوثيق النصي وحده، وظهرت فقط عبر التحليل الساكن الفعلي.
2. **API متزامن (`startTextSearch`) ظننته `Future`** بدون سبب وجيه —
   درس مهم: لا أفترض `async` لمجرد أن الاسم يوحي بعملية قد تستغرق وقتًا.

لا توجد أخطاء منطقية أو معمارية — فقط تفاصيل توقيع دوال دقيقة، وهو بالضبط
نوع الأخطاء التي يكشفها `flutter analyze` الفعلي وليس المراجعة النصية.
