// اختبار دخان (Smoke Test) بسيط: يتأكد فقط أن التطبيق يُبنى بدون أخطاء.
//
// ملاحظة: قالب `flutter create` الافتراضي يُنشئ هذا الملف مشيرًا لكلاس
// اسمه `MyApp`، وهو غير موجود في هذا المشروع (اسم التطبيق الفعلي هو
// `IslamicLibraryApp`، انظر lib/app/app.dart) — من هنا جاء خطأ
// `creation_with_non_type` في flutter analyze. هذا الملف مصحَّح ليطابق
// الاسم الحقيقي.

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:islamic_library/app/app.dart';

void main() {
  testWidgets('IslamicLibraryApp builds without throwing', (tester) async {
    await tester.pumpWidget(
      const ProviderScope(child: IslamicLibraryApp()),
    );
    // ننتظر استقرار أول إطار فقط (بدون تفاعل)؛ التحقق التفصيلي بالشاشات
    // يُضاف لاحقًا كاختبارات مخصصة لكل شاشة عند الحاجة.
    await tester.pump();
  });
}
