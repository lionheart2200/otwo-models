# تصحيحات ما بعد المراجعة — إصدارات الحزم وAPIs حديثة فعليًا

راجعت pub.dev وGitHub الرسمي لكل حزمة حرجة (وليس من الذاكرة)، ووجدت
فعلًا ما أشرت إليه: إصدارات قديمة + استخدام API غير مطابق لأحدث إصدار.
هذه قائمة كل ما صُحِّح، مع المصدر الذي اعتمدت عليه لكل تصحيح.

## 1) Riverpod 3.x — التغيير الأهم

**المشكلة:** `pubspec.yaml` كان يحدد `flutter_riverpod: ^2.5.1`، لكن
الإصدار الحالي فعليًا هو **3.x** (تحقّقت من `pub.dev/packages/flutter_riverpod`
و`riverpod.dev/docs/introduction/getting_started`). في Riverpod 3.x
انتقلت `StateNotifier` و`StateNotifierProvider` من `flutter_riverpod.dart`
الأساسي إلى ملف منفصل `flutter_riverpod/legacy.dart`.

**التصحيح:** رفعت `pubspec.yaml` إلى `^3.0.3`، وأضفت
`import 'package:flutter_riverpod/legacy.dart';` في كل ملف يستخدم
`StateNotifier`:
- `presentation/providers/app_providers.dart`
- `presentation/providers/theme_provider.dart`
- `presentation/reader/providers/reader_providers.dart`
- `presentation/auth/providers/auth_providers.dart`

## 2) pdfrx — إصدار قديم جدًا + خطأ فعلي في تمييز نتائج البحث

**المشكلة الأولى:** `pubspec.yaml` كان `pdfrx: ^0.4.0`، بينما الإصدار
الرسمي الحالي المذكور في README الرسمي للمستودع هو **`^2.4.4`**
(`github.com/espresso3389/pdfrx`، ملف `packages/pdfrx/README.md`).

**المشكلة الثانية (خطأ فعلي كنت سأكتشفه فقط عند التجميع):** في
`reader_screen.dart`، كنت قد اخترعت دالة باسم `_textSearcher.paintHighlights(...)`
لا وجود لها في الحزمة أصلًا. راجعت `doc/Text-Search.md` الرسمي في
المستودع ووجدت أن الصحيح هو استخدام **خاصية جاهزة** اسمها
`pageTextMatchPaintCallback` مباشرة:

```dart
pagePaintCallbacks: [_textSearcher.pageTextMatchPaintCallback],
```

كما أضفت `addListener`/`removeListener` على `PdfTextSearcher` (كما في
المثال الرسمي بالضبط) لإعادة رسم التمييز فور توفر نتائج جديدة، وهو ما
كان ناقصًا في الكود الأصلي.

**نقطة لم تُحسم 100%:** اسم خاصية النص الكامل على `PdfPageText` في
`pdf_text_extractor.dart` (استخدمت `.fullText`). التوثيق أكّد أن
`page.loadText()` يُعيد فعليًا `Future<PdfPageText>` (غير Nullable) —
وهذا مطابق لما كتبته — لكن لم أصل لتأكيد قاطع 100% لاسم الخاصية الداخلية
عبر المصادر المتاحة لي. إن اختلف الاسم، الخطأ سيكون واضحًا وموضعيًا
(سطر واحد) عند أول `flutter analyze`.

**إضافة أخرى per التوثيق الرسمي:** أضفت استدعاء `pdfrxFlutterInitialize()`
في `main.dart` وداخل `extractPdfText()` نفسها (لأنها تعمل داخل Isolate
خلفي منفصل) — موصى به رسميًا عند الوصول لـ `PdfDocument` مباشرة دون المرور
بودجت `PdfViewer` أولًا.

## 3) drift — رقم إصدار دقيق حسب التوثيق الرسمي

حدّثت من `2.16.0` إلى `2.34.1` (drift) و`2.34.2+1` (drift_dev) و`0.2.7`
(drift_flutter) و`2.15.0` (build_runner) — مطابقة تمامًا لصفحة الإعداد
الرسمية `drift.simonbinder.eu/setup`. لم تتغيّر أي API استخدمتها فعليًا
(الجداول، `@DriftDatabase`، `customSelect`، `batch`) بين هذين الإصدارين.

## 4) go_router وdio وباقي الحزم

- `go_router`: من `^14.2.0` إلى `^16.2.0` — الـ API الذي استخدمته
  (`GoRoute`, `ShellRoute`, `state.pathParameters`, `context.push/go/pop`)
  مستقر ومطابق في كلا الإصدارين (تحقّقت من مثال حديث بتاريخ إبريل 2026).
- `dio`: من `^5.4.3+1` إلى `^5.9.2`.
- `shared_preferences`, `path_provider`, `crypto`, `path`, `flutter_svg`,
  `cupertino_icons`: رُفعت لأحدث إصدار ثابت متوافق (APIs هذه الحزم لم
  تتغيّر بشكل جوهري).
- رفعت الحد الأدنى لإصدار Dart SDK في `environment.sdk` إلى `>=3.7.0`
  لأن Riverpod 3.x وgo_router 16.x يتطلبان ذلك رسميًا.

## ما لم أستطع التحقق منه 100%

كل التصحيحات أعلاه مبنية على توثيق رسمي فعلي راجعته الآن (روابط pub.dev
وGitHub)، وليس من الذاكرة. الاستثناء الوحيد المتبقي هو اسم خاصية النص
الكامل في `PdfPageText` المذكور في القسم 2 — وهو معزول في سطر واحد فقط
في `pdf_text_extractor.dart`، ومُعلَّق عليه بوضوح في الكود نفسه.

## توصية عملية

عند فتح المشروع فعليًا في VS Code لأول مرة:
```bash
flutter pub get
flutter analyze
```
`flutter analyze` سيُظهر فورًا أي اسم API غير مطابق (إن وُجد) بدقة سطر
وملف، وهذا أوثق من أي مراجعة يدوية بدون بيئة تنفيذ فعلية.
