# المكتبة الإسلامية الشاملة — المرحلة 2: قاعدة البيانات + نظام البحث

## ما تم إنجازه في هذه المرحلة

- **مخطط قاعدة بيانات كامل** عبر Drift (13 جدولًا) يغطي: الأقسام، المجلدات
  الهرمية غير المحدودة، المؤلفين، دور النشر، الكتب، تقدم القراءة، المفضلة،
  القوائم الشخصية، العلامات المرجعية، الملاحظات، الاقتباسات المحفوظة،
  وسجل البحث.
- **جدول FTS5** (`pages_fts`) لفهرسة نص كل صفحة من كل كتاب، منشأ عبر SQL
  خام لضمان دقة صياغة `tokenize` و`UNINDEXED`.
- **أداة تطبيع نص عربي** (`ArabicTextNormalizer`) تحل مشكلة الهمزات
  والتشكيل والتطويل، وتُستخدم في الفهرسة والبحث معًا بنفس المنطق تمامًا.
- **محرك بحث كامل** (`SearchEngine`) يستخدم `bm25()` للترتيب حسب الصلة
  و`snippet()` المدمجة في FTS5 لاستخراج المقتطف النصي مع تمييز الموضع —
  بدون أي خوارزمية ترتيب أو اقتطاع نص يدوية.
- **استخراج نص PDF داخل Isolate منفصل** (`extractPdfText`) بحيث لا تتجمد
  الواجهة أبدًا أثناء معالجة كتاب كبير.
- **خدمة فهرسة بطابور تسلسلي** (`PdfIndexingService`) تفهرس كتابًا واحدًا
  في كل مرة، تكتشف الصفحات الممسوحة ضوئيًا (بحاجة OCR مستقبلًا)، وتبث
  تقدم الفهرسة عبر Stream لعرضه في الواجهة.
- **طبقة Domain نقية** (Entities + Repository Interfaces) منفصلة تمامًا
  عن Drift/Flutter.
- **تنفيذ فعلي لطبقة Data** لـ Books وSearch Repositories.
- **Riverpod Providers** تربط كل الطبقات، بما فيها `SearchNotifier` الذي
  يطبّق Debounce حقيقي (300ms) على البحث الفوري.

## خطوات التشغيل

```bash
flutter pub get
dart run build_runner build --delete-conflicting-outputs
```

الأمر الثاني **ضروري** لأن `app_database.dart` يعتمد على كود مولّد
(`app_database.g.dart`) عبر `drift_dev` — لن يُبنى المشروع بدون تشغيله.

## ملاحظة مهمة حول حزمة قراءة PDF

في `lib/core/pdf/pdf_text_extractor.dart` استُخدمت حزمة `pdfrx` بصيغة
API الشائعة لاستخراج النص (`PdfDocument.openFile`, `page.loadText()`).
تأكد عند التنفيذ الفعلي من مطابقة الأسماء الدقيقة للإصدار المثبت لديك في
`pubspec.lock`، لأن حزم قراءة PDF في Flutter تُحدَّث بشكل متكرر نسبيًا،
وإن اختلف الاسم فالتعديل سطر أو سطرين فقط دون أي تغيير في بقية المعمارية.

## هيكل الملفات المُنشأة في هذه المرحلة

```
lib/
├── core/
│   ├── database/
│   │   ├── app_database.dart
│   │   └── tables/
│   │       ├── sections_table.dart
│   │       ├── folders_table.dart
│   │       ├── authors_table.dart
│   │       ├── books_table.dart
│   │       ├── reading_progress_table.dart
│   │       └── user_library_tables.dart
│   ├── utils/
│   │   └── arabic_text_normalizer.dart
│   ├── search/
│   │   ├── search_engine.dart
│   │   └── models/search_result.dart
│   └── pdf/
│       ├── pdf_text_extractor.dart
│       └── pdf_indexing_service.dart
├── domain/
│   ├── entities/entities.dart
│   └── repositories/repositories.dart
├── data/
│   ├── mappers/entity_mappers.dart
│   └── repositories/
│       ├── search_repository_impl.dart
│       └── books_repository_impl.dart
└── presentation/
    └── providers/app_providers.dart
```

## الخطوة التالية (المرحلة 3)

1. تصميم قارئ PDF (الواجهة + التنقل لصفحة النتيجة + التمييز البصري
   للكلمة المطلوبة).
2. واجهات: الشاشة الرئيسية، الأقسام، البحث، مكتبتي، الإعدادات.
3. نظام التنزيل (Dio + إيقاف/استكمال) وربطه بـ `PdfIndexingService`
   تلقائيًا بعد اكتمال كل تنزيل.
