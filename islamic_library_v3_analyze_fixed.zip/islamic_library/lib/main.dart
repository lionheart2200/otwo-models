import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:pdfrx/pdfrx.dart';

import 'app/app.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  // موصى به رسميًا عند التعامل مع PdfDocument مباشرة (مثل الفهرسة في
  // الخلفية) وليس فقط عبر ودجت PdfViewer.
  pdfrxFlutterInitialize();
  runApp(const ProviderScope(child: IslamicLibraryApp()));
}
