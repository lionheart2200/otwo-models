import 'package:flutter/material.dart';

/// هوية لونية إسلامية عصرية: أخضر زُمردي هادئ + ذهبي كلون ثانوي للتمييز
/// (اقتباسات، تمييز نتائج البحث)، بعيدًا عن الألوان التقليدية الصاخبة.
class AppColors {
  AppColors._();

  // اللون الأساسي (Primary) - أخضر هادئ يوحي بالسكينة والقراءة الطويلة
  static const primary = Color(0xFF1F6E5C);
  static const primaryLight = Color(0xFF4C9C87);
  static const primaryDark = Color(0xFF124238);

  // اللون الثانوي - ذهبي مطفأ للتمييز (اقتباسات، Highlight نتائج البحث)
  static const accentGold = Color(0xFFC79A3C);

  // خلفيات
  static const lightBackground = Color(0xFFF7F5F0);
  static const lightSurface = Color(0xFFFFFFFF);
  static const darkBackground = Color(0xFF101613);
  static const darkSurface = Color(0xFF1A211D);

  // وضع القراءة الليلية داخل القارئ (أدفأ من الوضع الداكن العام)
  static const readerNightBackground = Color(0xFF1E1B16);
  static const readerNightText = Color(0xFFD9D2C4);

  // وضع القراءة السيبيا (اختياري مريح للعين نهارًا)
  static const readerSepiaBackground = Color(0xFFF4ECD8);

  static const textPrimaryLight = Color(0xFF20261F);
  static const textSecondaryLight = Color(0xFF5B655C);
  static const textPrimaryDark = Color(0xFFE7EBE5);
  static const textSecondaryDark = Color(0xFFA3ADA2);

  static const searchHighlight = Color(0xFFF5D373);
  static const error = Color(0xFFB3261E);
}
