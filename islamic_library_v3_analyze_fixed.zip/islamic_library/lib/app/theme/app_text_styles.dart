import 'package:flutter/material.dart';

/// خط "Cairo" أو "Tajawal" أنسب من الخطوط الافتراضية للعربية طويلة القراءة.
/// نفترض أنه مضاف عبر google_fonts أو ملفات الخط المحلية في pubspec.
/// (يُترك اسم العائلة كثابت هنا ليسهل تبديله من مكان واحد فقط)
class AppTextStyles {
  AppTextStyles._();

  static const String fontFamily = 'Cairo';
  static const String readerFontFamily = 'Amiri'; // خط قراءة كتب تقليدي مريح

  static const TextStyle screenTitle = TextStyle(
    fontFamily: fontFamily,
    fontSize: 22,
    fontWeight: FontWeight.w700,
    height: 1.4,
  );

  static const TextStyle sectionTitle = TextStyle(
    fontFamily: fontFamily,
    fontSize: 17,
    fontWeight: FontWeight.w600,
    height: 1.4,
  );

  static const TextStyle bookTitle = TextStyle(
    fontFamily: fontFamily,
    fontSize: 14,
    fontWeight: FontWeight.w600,
    height: 1.5,
  );

  static const TextStyle body = TextStyle(
    fontFamily: fontFamily,
    fontSize: 14,
    fontWeight: FontWeight.w400,
    height: 1.6,
  );

  static const TextStyle caption = TextStyle(
    fontFamily: fontFamily,
    fontSize: 12,
    fontWeight: FontWeight.w400,
    height: 1.4,
  );

  /// نمط نص القارئ الأساسي — قابل لتغيير الحجم من إعدادات القارئ
  static TextStyle readerText({double fontSize = 18, Color? color}) {
    return TextStyle(
      fontFamily: readerFontFamily,
      fontSize: fontSize,
      height: 1.9,
      color: color,
    );
  }
}
