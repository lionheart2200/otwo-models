import 'package:go_router/go_router.dart';

import '../presentation/shell/adaptive_shell.dart';
import '../presentation/home/home_screen.dart';
import '../presentation/sections/sections_screen.dart';
import '../presentation/search/search_screen.dart';
import '../presentation/library/library_screen.dart';
import '../presentation/settings/settings_screen.dart';
import '../presentation/reader/reader_screen.dart';
import '../presentation/book_details/book_details_screen.dart';
import '../presentation/quran/quran_section_screen.dart';

final appRouter = GoRouter(
  initialLocation: '/home',
  routes: [
    ShellRoute(
      builder: (context, state, child) {
        return AdaptiveShell(currentPath: state.uri.path, child: child);
      },
      routes: [
        GoRoute(path: '/home', builder: (context, state) => const HomeScreen()),
        GoRoute(
          path: '/sections',
          builder: (context, state) => const SectionsScreen(),
          routes: [
            GoRoute(
              path: ':sectionId',
              builder: (context, state) {
                final sectionId = int.parse(state.pathParameters['sectionId']!);
                final sectionName = state.extra as String?;

                // قسم "القرآن الكريم" يحصل على واجهة مميزة (بند تاسعًا في
                // الطلب)؛ باقي الأقسام تستخدم متصفح المجلدات العام.
                if (sectionName == 'القرآن الكريم') {
                  return QuranSectionScreen(sectionId: sectionId);
                }
                return FolderBrowserScreen(
                  sectionId: sectionId,
                  title: sectionName ?? 'القسم',
                );
              },
              routes: [
                GoRoute(
                  path: 'folder/:folderId',
                  builder: (context, state) {
                    final sectionId = int.parse(state.pathParameters['sectionId']!);
                    final folderId = int.parse(state.pathParameters['folderId']!);
                    return FolderBrowserScreen(
                      sectionId: sectionId,
                      folderId: folderId,
                      title: (state.extra as String?) ?? 'مجلد',
                    );
                  },
                ),
              ],
            ),
          ],
        ),
        GoRoute(path: '/search', builder: (context, state) => const SearchScreen()),
        GoRoute(path: '/library', builder: (context, state) => const LibraryScreen()),
        GoRoute(path: '/settings', builder: (context, state) => const SettingsScreen()),
      ],
    ),

    // شاشة تفاصيل الكتاب — خارج الـ Shell لأنها شاشة تركيز فوق أي تبويب.
    GoRoute(
      path: '/book/:bookId',
      builder: (context, state) {
        final bookId = int.parse(state.pathParameters['bookId']!);
        return BookDetailsScreen(bookId: bookId);
      },
    ),

    // القارئ يُفتح خارج الـ Shell (بدون شريط تنقل سفلي) لأنه شاشة تركيز
    // كاملة، ويقبل page/highlight كـ Query Parameters القادمة من نتيجة بحث.
    GoRoute(
      path: '/reader/:bookId',
      builder: (context, state) {
        final bookId = int.parse(state.pathParameters['bookId']!);
        final page = state.uri.queryParameters['page'];
        final highlight = state.uri.queryParameters['highlight'];
        return ReaderScreen(
          bookId: bookId,
          initialPage: page != null ? int.tryParse(page) : null,
          highlightQuery: highlight != null ? Uri.decodeComponent(highlight) : null,
        );
      },
    ),
  ],
);
