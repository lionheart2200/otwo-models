import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../domain/entities/entities.dart';

/// بطاقة كتاب موحّدة (غلاف + عنوان + مؤلف) تُستخدم في الرئيسية، الأقسام،
/// المكتبة الشخصية، ونتائج البحث حسب الحاجة، لتفادي تكرار نفس التصميم.
class BookCard extends StatelessWidget {
  final BookEntity book;
  final double width;

  const BookCard({super.key, required this.book, this.width = 130});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => context.push('/book/${book.id}'),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            AspectRatio(
              aspectRatio: 3 / 4,
              child: Container(
                clipBehavior: Clip.antiAlias,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: Theme.of(context).colorScheme.primaryContainer,
                ),
                child: book.coverImagePath != null
                    ? Image.asset(book.coverImagePath!, fit: BoxFit.cover)
                    : Center(
                        child: Icon(
                          Icons.menu_book_outlined,
                          color: Theme.of(context).colorScheme.onPrimaryContainer,
                          size: 36,
                        ),
                      ),
              ),
            ),
            const SizedBox(height: 6),
            Text(
              book.title,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            if (book.author != null)
              Text(
                book.author!.name,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: Theme.of(context).textTheme.bodySmall,
              ),
          ],
        ),
      ),
    );
  }
}

/// صف أفقي قابل للتمرير من بطاقات الكتب مع عنوان قسم فوقه
/// (يُستخدم لكل من: تابع القراءة، أضيف حديثًا، الأكثر قراءة...)
class BookRowSection extends StatelessWidget {
  final String title;
  final List<BookEntity> books;

  const BookRowSection({super.key, required this.title, required this.books});

  @override
  Widget build(BuildContext context) {
    if (books.isEmpty) return const SizedBox.shrink();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Text(title, style: Theme.of(context).textTheme.titleMedium),
        ),
        const SizedBox(height: 10),
        SizedBox(
          height: 200,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: books.length,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (context, i) => BookCard(book: books[i]),
          ),
        ),
        const SizedBox(height: 20),
      ],
    );
  }
}
