import 'dart:async';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

enum DownloadState { queued, downloading, paused, completed, failed, canceled }

class DownloadTask {
  final int bookId;
  final String remoteUrl;
  final String fileName;
  int receivedBytes;
  int totalBytes;
  DownloadState state;
  CancelToken? cancelToken;

  DownloadTask({
    required this.bookId,
    required this.remoteUrl,
    required this.fileName,
    this.receivedBytes = 0,
    this.totalBytes = 0,
    this.state = DownloadState.queued,
    this.cancelToken,
  });

  double get progress => totalBytes == 0 ? 0 : receivedBytes / totalBytes;
}

/// خدمة تنزيل الكتب. تدعم:
/// - تنزيل مع تتبع تقدم فعلي (bytes / total)
/// - إيقاف التنزيل (عبر CancelToken) مع الاحتفاظ بالبايتات المُنزَّلة جزئيًا
/// - استكمال التنزيل من حيث توقف عبر HTTP Range Header
/// - حذف الكتاب المُنزَّل ومعرفة المساحة المستخدمة
class DownloadService {
  final Dio _dio = Dio();
  final Map<int, DownloadTask> _tasks = {};
  final _updatesController = StreamController<DownloadTask>.broadcast();

  Stream<DownloadTask> get updates => _updatesController.stream;
  DownloadTask? taskFor(int bookId) => _tasks[bookId];

  Future<Directory> _booksDirectory() async {
    final baseDir = await getApplicationDocumentsDirectory();
    final booksDir = Directory(p.join(baseDir.path, 'books'));
    if (!await booksDir.exists()) {
      await booksDir.create(recursive: true);
    }
    return booksDir;
  }

  /// المسار المحلي النهائي لملف كتاب معيّن — عام (public) لأن
  /// app_providers.dart يحتاجه لتحديث حقل localFilePath في قاعدة البيانات
  /// فور اكتمال التنزيل.
  Future<String> localFilePath(int bookId, String fileName) async {
    final dir = await _booksDirectory();
    return p.join(dir.path, '${bookId}_$fileName');
  }

  /// بدء تنزيل جديد أو استئناف تنزيل متوقف لنفس الكتاب.
  Future<void> download({
    required int bookId,
    required String remoteUrl,
    required String fileName,
  }) async {
    final localPath = await localFilePath(bookId, fileName);
    final partialFile = File(localPath);
    final alreadyDownloadedBytes =
        await partialFile.exists() ? await partialFile.length() : 0;

    final task = _tasks[bookId] ??
        DownloadTask(bookId: bookId, remoteUrl: remoteUrl, fileName: fileName);
    task.receivedBytes = alreadyDownloadedBytes;
    task.state = DownloadState.downloading;
    task.cancelToken = CancelToken();
    _tasks[bookId] = task;
    _updatesController.add(task);

    try {
      // Range Header يسمح باستكمال التنزيل من آخر بايت محفوظ محليًا
      final response = await _dio.get<ResponseBody>(
        remoteUrl,
        options: Options(
          responseType: ResponseType.stream,
          headers: alreadyDownloadedBytes > 0
              ? {'Range': 'bytes=$alreadyDownloadedBytes-'}
              : null,
        ),
        cancelToken: task.cancelToken,
      );

      final contentLength = response.headers.value(Headers.contentLengthHeader);
      task.totalBytes = alreadyDownloadedBytes + (int.tryParse(contentLength ?? '') ?? 0);

      final sink = partialFile.openWrite(
        mode: alreadyDownloadedBytes > 0 ? FileMode.append : FileMode.write,
      );

      await for (final chunk in response.data!.stream) {
        sink.add(chunk);
        task.receivedBytes += chunk.length;
        _updatesController.add(task);
      }

      await sink.close();
      task.state = DownloadState.completed;
      _updatesController.add(task);
    } on DioException catch (e) {
      if (CancelToken.isCancel(e)) {
        task.state = DownloadState.paused;
      } else {
        task.state = DownloadState.failed;
      }
      _updatesController.add(task);
    }
  }

  /// إيقاف التنزيل مؤقتًا — البايتات المُنزَّلة تبقى محفوظة على القرص
  /// ليُكمل منها download() لاحقًا عبر Range Header.
  void pause(int bookId) {
    _tasks[bookId]?.cancelToken?.cancel('paused_by_user');
  }

  Future<void> cancelAndDelete(int bookId) async {
    _tasks[bookId]?.cancelToken?.cancel('canceled_by_user');
    final task = _tasks[bookId];
    if (task != null) {
      final path = await localFilePath(bookId, task.fileName);
      final file = File(path);
      if (await file.exists()) await file.delete();
      task.state = DownloadState.canceled;
      _updatesController.add(task);
    }
    _tasks.remove(bookId);
  }

  Future<int> totalStorageUsedBytes() async {
    final dir = await _booksDirectory();
    if (!await dir.exists()) return 0;
    var total = 0;
    await for (final entity in dir.list()) {
      if (entity is File) total += await entity.length();
    }
    return total;
  }

  void dispose() => _updatesController.close();
}
