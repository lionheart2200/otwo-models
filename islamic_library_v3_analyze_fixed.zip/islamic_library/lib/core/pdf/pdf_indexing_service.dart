import 'dart:async';
import 'dart:isolate';

import 'package:drift/drift.dart';

import '../database/app_database.dart';
import '../utils/arabic_text_normalizer.dart';
import 'pdf_text_extractor.dart';

/// حالة تقدم فهرسة كتاب واحد، تُبث عبر Stream ليستمع إليها Provider
/// في الواجهة (شريط تقدم عام، أو أيقونة "جارٍ الفهرسة" بجانب الكتاب).
class IndexingProgress {
  final int bookId;
  final int pagesDone;
  final int totalPages;
  final IndexingStatus status;

  const IndexingProgress({
    required this.bookId,
    required this.pagesDone,
    required this.totalPages,
    required this.status,
  });

  double get percent => totalPages == 0 ? 0 : pagesDone / totalPages;
}

/// يدير فهرسة الكتب **كتابًا واحدًا في كل مرة** (طابور تسلسلي) حتى لا
/// تتنافس عدة عمليات فهرسة ثقيلة على المعالج والذاكرة في آن واحد،
/// كما طلبت في بند "عدم تجميد واجهة المستخدم أثناء الفهرسة".
class PdfIndexingService {
  final AppDatabase _db;
  final _progressController = StreamController<IndexingProgress>.broadcast();
  final List<int> _queue = [];
  bool _isProcessing = false;

  PdfIndexingService(this._db);

  Stream<IndexingProgress> get progressStream => _progressController.stream;

  /// إضافة كتاب لطابور الفهرسة. إن كان الطابور فارغًا يبدأ التنفيذ فورًا.
  void enqueueBook(int bookId) {
    if (_queue.contains(bookId)) return;
    _queue.add(bookId);
    if (!_isProcessing) _processQueue();
  }

  Future<void> _processQueue() async {
    _isProcessing = true;
    while (_queue.isNotEmpty) {
      final bookId = _queue.removeAt(0);
      await _indexSingleBook(bookId);
    }
    _isProcessing = false;
  }

  Future<void> _indexSingleBook(int bookId) async {
    final book = await (_db.select(_db.books)
          ..where((b) => b.id.equals(bookId)))
        .getSingleOrNull();

    if (book == null || book.localFilePath == null) return;

    await _updateStatus(bookId, IndexingStatus.indexing);
    await _db.deleteBookFromIndex(bookId); // إعادة الفهرسة تمسح القديم أولًا

    // الاستخراج الفعلي يتم في Isolate منفصل تمامًا حتى لا يؤثر على أي
    // شيء آخر يعمل على الـ Main Isolate (بما فيها هذه الخدمة نفسها).
    final result = await Isolate.run(() => extractPdfText(book.localFilePath!));

    if (!result.success) {
      await _updateStatus(bookId, IndexingStatus.failed);
      _progressController.add(IndexingProgress(
        bookId: bookId,
        pagesDone: 0,
        totalPages: 0,
        status: IndexingStatus.failed,
      ));
      return;
    }

    // إن كانت كل صفحات الكتاب تقريبًا بلا نص حقيقي => كتاب صور ممسوحة بالكامل
    final scannedPagesRatio = result.pages.isEmpty
        ? 1.0
        : result.pages.where((p) => p.looksLikeScannedImage).length /
            result.pages.length;

    if (scannedPagesRatio > 0.9) {
      await _updateStatus(bookId, IndexingStatus.needsOcr);
      _progressController.add(IndexingProgress(
        bookId: bookId,
        pagesDone: 0,
        totalPages: result.totalPages,
        status: IndexingStatus.needsOcr,
      ));
      return;
    }

    // بناء دفعات إدخال (Batch) بحجم معقول بدل إدخال 800 صفحة دفعة واحدة
    // في استعلام واحد ضخم، وبدل إدخالها صفحة صفحة (بطيء جدًا).
    const batchSize = 50;
    final entries = <PageIndexEntry>[];
    var done = 0;

    for (final page in result.pages) {
      if (page.looksLikeScannedImage) continue; // تُستثنى فرديًا إن وُجدت

      entries.add(PageIndexEntry(
        bookId: bookId,
        pageNumber: page.pageNumber,
        originalText: page.text,
        normalizedText: ArabicTextNormalizer.normalize(page.text),
      ));

      if (entries.length >= batchSize) {
        await _db.insertPagesBatch(entries);
        entries.clear();
      }

      done++;
      _progressController.add(IndexingProgress(
        bookId: bookId,
        pagesDone: done,
        totalPages: result.totalPages,
        status: IndexingStatus.indexing,
      ));
    }

    if (entries.isNotEmpty) {
      await _db.insertPagesBatch(entries);
    }

    await (_db.update(_db.books)..where((b) => b.id.equals(bookId))).write(
      BooksCompanion(
        indexingStatus: Value(IndexingStatus.indexed),
        pageCount: Value(result.totalPages),
      ),
    );

    _progressController.add(IndexingProgress(
      bookId: bookId,
      pagesDone: result.totalPages,
      totalPages: result.totalPages,
      status: IndexingStatus.indexed,
    ));
  }

  Future<void> _updateStatus(int bookId, IndexingStatus status) async {
    await (_db.update(_db.books)..where((b) => b.id.equals(bookId)))
        .write(BooksCompanion(indexingStatus: Value(status)));
  }

  void dispose() => _progressController.close();
}
