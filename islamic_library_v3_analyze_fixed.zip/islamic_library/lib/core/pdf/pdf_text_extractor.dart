import 'package:pdfrx/pdfrx.dart';

/// نص صفحة واحدة مستخرج من ملف PDF
class ExtractedPage {
  final int pageNumber; // يبدأ من 1
  final String text;
  final bool looksLikeScannedImage; // نص فارغ/شبه فارغ => يحتاج OCR مستقبلًا

  const ExtractedPage({
    required this.pageNumber,
    required this.text,
    required this.looksLikeScannedImage,
  });
}

class PdfExtractionResult {
  final List<ExtractedPage> pages;
  final int totalPages;
  final bool success;
  final String? errorMessage;

  const PdfExtractionResult({
    required this.pages,
    required this.totalPages,
    required this.success,
    this.errorMessage,
  });
}

/// عتبة طول النص التي دونها نعتبر الصفحة "بدون نص حقيقي" (صورة ممسوحة)
const int _minTextLengthThreshold = 20;

/// دالة Top-Level (وليست Method) عمدًا، لأنها الشرط اللازم لتشغيلها
/// داخل Isolate عبر `Isolate.run` — تُستدعى من PdfIndexingService.
///
/// مصادر مؤكدة من التوثيق الرسمي (github.com/espresso3389/pdfrx، تم
/// التحقق منها فعليًا وقت كتابة هذا الكود):
/// - `PdfDocument.openFile(path)` يعيد `Future<PdfDocument>`.
/// - `document.pages` قائمة صفحات (`List<PdfPage>`)، والصفحة الأولى رقمها 1.
/// - `page.loadText()` يعيد `Future<PdfPageText>` (غير Nullable).
///
/// النقطة الوحيدة غير المؤكدة 100% هنا هي **اسم خاصية النص الكامل** على
/// `PdfPageText` (استخدمتها هنا كـ `.fullText` بناءً على الاتفاقية
/// الشائعة في هذه الحزمة). إن اختلف الاسم في إصدارك المثبت، ستظهر رسالة
/// خطأ تجميع واضحة في هذا الموضع تحديدًا وتصحيحها سطر واحد لا أكثر.
///
/// ملاحظة تقنية إضافية: نستدعي `pdfrxFlutterInitialize()` هنا احتياطيًا
/// لأن هذه الدالة تُنفَّذ داخل Isolate خلفي منفصل تمامًا عن الـ Isolate
/// الرئيسي الذي بُنيت فيه واجهة التطبيق، وربط pdfium الأصلي قد يحتاج
/// تهيئة صريحة في كل Isolate يستخدمه بشكل مباشر (بدون واجهة).
Future<PdfExtractionResult> extractPdfText(String filePath) async {
  pdfrxFlutterInitialize();

  PdfDocument? document;
  try {
    document = await PdfDocument.openFile(filePath);
    final pages = <ExtractedPage>[];

    for (var i = 0; i < document.pages.length; i++) {
      final page = document.pages[i];
      // flutter analyze أكّد أن loadText() يُعيد Future<PdfPageText?>
      // (قابل لـ null فعليًا خلافًا لما أشارت له صفحة التوثيق)، لكنه أكّد
      // أيضًا أن `.fullText` هو الاسم الصحيح للخاصية — لذا المعالجة هنا
      // فقط إضافة `?.` مع قيمة افتراضية فارغة عند null.
      final pageText = await page.loadText();
      final text = (pageText?.fullText ?? '').trim();

      pages.add(
        ExtractedPage(
          pageNumber: i + 1,
          text: text,
          looksLikeScannedImage: text.length < _minTextLengthThreshold,
        ),
      );
    }

    return PdfExtractionResult(
      pages: pages,
      totalPages: document.pages.length,
      success: true,
    );
  } catch (e) {
    return PdfExtractionResult(
      pages: const [],
      totalPages: 0,
      success: false,
      errorMessage: e.toString(),
    );
  } finally {
    await document?.dispose();
  }
}
