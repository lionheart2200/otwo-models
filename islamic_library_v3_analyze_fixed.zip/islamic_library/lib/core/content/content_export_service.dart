import 'dart:convert';

import '../database/app_database.dart';
import 'content_seed_models.dart';

/// يقرأ محتوى المكتبة الحالي على جهاز الأدمن (أقسام/مؤلفون/دور نشر/
/// مجلدات/كتب فقط — بدون أي بيانات مستخدم شخصية) ويحوّله لحزمة JSON
/// جاهزة لوضعها في assets/content/seed_content.json قبل رفع تحديث جديد.
class ContentExportService {
  final AppDatabase _db;
  ContentExportService(this._db);

  /// يبني مسار المجلد الكامل (أسماء الآباء من الجذر حتى المجلد نفسه)
  /// عبر تتبع parentFolderId صعودًا — يُستخدم لأن معرّفات قاعدة البيانات
  /// الرقمية تختلف من جهاز لآخر، بينما الأسماء تبقى مفتاحًا مستقرًا.
  Future<List<String>> _ancestorPath(Folder folder, Map<int, Folder> allFolders) async {
    final path = <String>[];
    Folder? current = folder;
    while (current?.parentFolderId != null) {
      current = allFolders[current!.parentFolderId];
      if (current != null) path.insert(0, current.name);
    }
    return path;
  }

  Future<ContentSeedPackage> exportCurrentContent({required int contentVersion}) async {
    final sections = await _db.select(_db.sections).get();
    final authors = await _db.select(_db.authors).get();
    final publishers = await _db.select(_db.publishers).get();
    final folders = await _db.select(_db.folders).get();
    final books = await _db.select(_db.books).get();

    final sectionById = {for (final s in sections) s.id: s};
    final authorById = {for (final a in authors) a.id: a};
    final publisherById = {for (final p in publishers) p.id: p};
    final folderById = {for (final f in folders) f.id: f};

    final seedFolders = <SeedFolder>[];
    for (final folder in folders) {
      final section = sectionById[folder.sectionId];
      if (section == null) continue;
      final parentPath = await _ancestorPath(folder, folderById);
      seedFolders.add(SeedFolder(
        sectionName: section.name,
        parentPath: parentPath,
        name: folder.name,
        sortOrder: folder.sortOrder,
      ));
    }

    final seedBooks = <SeedBook>[];
    for (final book in books) {
      final section = sectionById[book.sectionId];
      if (section == null) continue;
      List<String> folderPath = [];
      if (book.folderId != null) {
        final folder = folderById[book.folderId];
        if (folder != null) {
          folderPath = [...await _ancestorPath(folder, folderById), folder.name];
        }
      }
      seedBooks.add(SeedBook(
        sectionName: section.name,
        folderPath: folderPath,
        authorName: book.authorId != null ? authorById[book.authorId]?.name : null,
        publisherName: book.publisherId != null ? publisherById[book.publisherId]?.name : null,
        title: book.title,
        description: book.description,
        edition: book.edition,
        remoteUrl: book.remoteUrl,
        keywords: book.keywords,
      ));
    }

    return ContentSeedPackage(
      contentVersion: contentVersion,
      exportedAt: DateTime.now(),
      sections: sections
          .map((s) => SeedSection(
                name: s.name,
                description: s.description,
                iconName: s.iconName,
                sortOrder: s.sortOrder,
              ))
          .toList(),
      authors: authors.map((a) => SeedAuthor(name: a.name, bio: a.bio, deathYear: a.deathYear)).toList(),
      publishers: publishers.map((p) => SeedPublisher(name: p.name)).toList(),
      folders: seedFolders,
      books: seedBooks,
    );
  }

  Future<String> exportAsJsonString({required int contentVersion}) async {
    final package = await exportCurrentContent(contentVersion: contentVersion);
    return const JsonEncoder.withIndent('  ').convert(package.toJson());
  }
}
