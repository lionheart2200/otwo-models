import 'package:drift/drift.dart';

import '../database/app_database.dart';
import 'content_seed_models.dart';

class ContentImportSummary {
  final int sectionsAdded;
  final int authorsAdded;
  final int publishersAdded;
  final int foldersAdded;
  final int booksAdded;
  final int booksUpdated;

  const ContentImportSummary({
    this.sectionsAdded = 0,
    this.authorsAdded = 0,
    this.publishersAdded = 0,
    this.foldersAdded = 0,
    this.booksAdded = 0,
    this.booksUpdated = 0,
  });
}

/// يدمج حزمة محتوى (من ContentExportService على جهاز الأدمن، مُغلَّفة
/// كملف assets/content/seed_content.json مع كل تحديث للتطبيق) داخل
/// قاعدة بيانات المستخدم المحلية — دون حذف أو التكرار مع ما أضافه
/// المستخدم بنفسه، ودون المساس ببياناته الشخصية (تقدّم قراءة، مفضلة...).
///
/// المطابقة تتم بالاسم (قسم/مؤلف/ناشر/مجلد بمساره الكامل/كتاب+مؤلفه)
/// لأن معرّفات قاعدة البيانات الرقمية تختلف من جهاز لآخر. هذا يعني: لا
/// تُنشئ قسمين بنفس الاسم عبر الاستيراد، وإذا عدّل الأدمن كتابًا موجودًا
/// (نفس العنوان + نفس المؤلف) في تحديث لاحق، تُحدَّث بياناته بدل تكراره.
class ContentImportService {
  final AppDatabase _db;
  ContentImportService(this._db);

  Future<ContentImportSummary> import(ContentSeedPackage package) async {
    var sectionsAdded = 0, authorsAdded = 0, publishersAdded = 0, foldersAdded = 0;
    var booksAdded = 0, booksUpdated = 0;

    // ---- الأقسام ----
    final sectionNameToId = <String, int>{};
    for (final existing in await _db.select(_db.sections).get()) {
      sectionNameToId[existing.name] = existing.id;
    }
    for (final s in package.sections) {
      if (sectionNameToId.containsKey(s.name)) continue;
      final id = await _db.into(_db.sections).insert(
            SectionsCompanion.insert(
              name: s.name,
              description: Value(s.description),
              iconName: Value(s.iconName),
              sortOrder: Value(s.sortOrder),
            ),
          );
      sectionNameToId[s.name] = id;
      sectionsAdded++;
    }

    // ---- المؤلفون ----
    final authorNameToId = <String, int>{};
    for (final existing in await _db.select(_db.authors).get()) {
      authorNameToId[existing.name] = existing.id;
    }
    for (final a in package.authors) {
      if (authorNameToId.containsKey(a.name)) continue;
      final id = await _db.into(_db.authors).insert(
            AuthorsCompanion.insert(
              name: a.name,
              bio: Value(a.bio),
              deathYear: Value(a.deathYear),
            ),
          );
      authorNameToId[a.name] = id;
      authorsAdded++;
    }

    // ---- دور النشر ----
    final publisherNameToId = <String, int>{};
    for (final existing in await _db.select(_db.publishers).get()) {
      publisherNameToId[existing.name] = existing.id;
    }
    for (final p in package.publishers) {
      if (publisherNameToId.containsKey(p.name)) continue;
      final id =
          await _db.into(_db.publishers).insert(PublishersCompanion.insert(name: p.name));
      publisherNameToId[p.name] = id;
      publishersAdded++;
    }

    // ---- المجلدات (مرتّبة من الأقل عمقًا للأكثر، حتى يكون الأب موجودًا
    // دائمًا قبل إنشاء ابنه) ----
    final sortedFolders = [...package.folders]
      ..sort((a, b) => a.parentPath.length.compareTo(b.parentPath.length));

    // المفتاح: "اسم القسم>مسار كامل بما فيه اسم المجلد نفسه"
    final folderPathToId = <String, int>{};

    for (final f in sortedFolders) {
      final sectionId = sectionNameToId[f.sectionName];
      if (sectionId == null) continue; // قسم غير معروف، تجاهل بأمان

      int? parentId;
      if (f.parentPath.isNotEmpty) {
        final parentKey = '${f.sectionName}>${f.parentPath.join("/")}';
        parentId = folderPathToId[parentKey];
        if (parentId == null) continue; // الأب غير موجود لسبب ما، تجاهل بأمان
      }

      final fullPath = [...f.parentPath, f.name].join('/');
      final fullKey = '${f.sectionName}>$fullPath';

      // فحص وجود مجلد بنفس الاسم تحت نفس الأب فعليًا في القاعدة (وليس
      // فقط في الخريطة المؤقتة)، لتفادي التكرار عبر استيرادات متعددة.
      final existingQuery = _db.select(_db.folders)
        ..where((t) => t.sectionId.equals(sectionId) & t.name.equals(f.name));
      if (parentId != null) {
        existingQuery.where((t) => t.parentFolderId.equals(parentId!));
      } else {
        existingQuery.where((t) => t.parentFolderId.isNull());
      }
      final existing = await existingQuery.getSingleOrNull();

      if (existing != null) {
        folderPathToId[fullKey] = existing.id;
        continue;
      }

      final id = await _db.into(_db.folders).insert(
            FoldersCompanion.insert(
              sectionId: sectionId,
              name: f.name,
              parentFolderId: Value(parentId),
              sortOrder: Value(f.sortOrder),
            ),
          );
      folderPathToId[fullKey] = id;
      foldersAdded++;
    }

    // ---- الكتب ----
    for (final b in package.books) {
      final sectionId = sectionNameToId[b.sectionName];
      if (sectionId == null) continue;

      int? folderId;
      if (b.folderPath.isNotEmpty) {
        final key = '${b.sectionName}>${b.folderPath.join("/")}';
        folderId = folderPathToId[key];
      }

      final authorId = b.authorName != null ? authorNameToId[b.authorName] : null;
      final publisherId = b.publisherName != null ? publisherNameToId[b.publisherName] : null;

      // مطابقة الكتاب الموجود بالعنوان + المؤلف (نفس منطق dedupe الموضّح
      // في تعليق الكلاس أعلاه).
      final existingQuery = _db.select(_db.books)..where((t) => t.title.equals(b.title));
      if (authorId != null) {
        existingQuery.where((t) => t.authorId.equals(authorId));
      } else {
        existingQuery.where((t) => t.authorId.isNull());
      }
      final existing = await existingQuery.getSingleOrNull();

      if (existing != null) {
        // تحديث بيانات وصفية فقط — لا يمسّ localFilePath أو isDownloaded
        // أو indexingStatus الخاصة بنسخة هذا المستخدم تحديدًا.
        await (_db.update(_db.books)..where((t) => t.id.equals(existing.id))).write(
          BooksCompanion(
            description: Value(b.description),
            edition: Value(b.edition),
            remoteUrl: Value(b.remoteUrl),
            keywords: Value(b.keywords),
            publisherId: Value(publisherId),
          ),
        );
        booksUpdated++;
        continue;
      }

      await _db.into(_db.books).insert(
            BooksCompanion.insert(
              sectionId: sectionId,
              title: b.title,
              folderId: Value(folderId),
              authorId: Value(authorId),
              publisherId: Value(publisherId),
              description: Value(b.description),
              edition: Value(b.edition),
              remoteUrl: Value(b.remoteUrl),
              keywords: Value(b.keywords),
            ),
          );
      booksAdded++;
    }

    return ContentImportSummary(
      sectionsAdded: sectionsAdded,
      authorsAdded: authorsAdded,
      publishersAdded: publishersAdded,
      foldersAdded: foldersAdded,
      booksAdded: booksAdded,
      booksUpdated: booksUpdated,
    );
  }
}
