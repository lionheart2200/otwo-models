/// نماذج بيانات "حزمة المحتوى" التي يصدّرها الأدمن محليًا، ثم تُوضع في
/// assets/content/seed_content.json قبل رفع كل تحديث للتطبيق للمتجر.
/// لا تحتوي أي بيانات خاصة بالمستخدم (لا مفضلة، لا تقدّم قراءة، لا
/// ملاحظات) — فقط محتوى المكتبة نفسه: أقسام، مؤلفون، دور نشر، مجلدات،
/// وكتب (بروابط تنزيل PDF، وليس الملفات نفسها).
library;

class ContentSeedPackage {
  final int contentVersion;
  final DateTime exportedAt;
  final List<SeedSection> sections;
  final List<SeedAuthor> authors;
  final List<SeedPublisher> publishers;
  final List<SeedFolder> folders;
  final List<SeedBook> books;

  const ContentSeedPackage({
    required this.contentVersion,
    required this.exportedAt,
    required this.sections,
    required this.authors,
    required this.publishers,
    required this.folders,
    required this.books,
  });

  Map<String, dynamic> toJson() => {
        'contentVersion': contentVersion,
        'exportedAt': exportedAt.toIso8601String(),
        'sections': sections.map((e) => e.toJson()).toList(),
        'authors': authors.map((e) => e.toJson()).toList(),
        'publishers': publishers.map((e) => e.toJson()).toList(),
        'folders': folders.map((e) => e.toJson()).toList(),
        'books': books.map((e) => e.toJson()).toList(),
      };

  factory ContentSeedPackage.fromJson(Map<String, dynamic> json) {
    return ContentSeedPackage(
      contentVersion: json['contentVersion'] as int,
      exportedAt: DateTime.parse(json['exportedAt'] as String),
      sections: (json['sections'] as List)
          .map((e) => SeedSection.fromJson(e as Map<String, dynamic>))
          .toList(),
      authors: (json['authors'] as List)
          .map((e) => SeedAuthor.fromJson(e as Map<String, dynamic>))
          .toList(),
      publishers: (json['publishers'] as List)
          .map((e) => SeedPublisher.fromJson(e as Map<String, dynamic>))
          .toList(),
      folders: (json['folders'] as List)
          .map((e) => SeedFolder.fromJson(e as Map<String, dynamic>))
          .toList(),
      books: (json['books'] as List)
          .map((e) => SeedBook.fromJson(e as Map<String, dynamic>))
          .toList(),
    );
  }
}

class SeedSection {
  final String name; // المفتاح الطبيعي للمطابقة عند الاستيراد
  final String? description;
  final String? iconName;
  final int sortOrder;

  const SeedSection({
    required this.name,
    required this.sortOrder,
    this.description,
    this.iconName,
  });

  Map<String, dynamic> toJson() => {
        'name': name,
        'description': description,
        'iconName': iconName,
        'sortOrder': sortOrder,
      };

  factory SeedSection.fromJson(Map<String, dynamic> j) => SeedSection(
        name: j['name'] as String,
        description: j['description'] as String?,
        iconName: j['iconName'] as String?,
        sortOrder: j['sortOrder'] as int? ?? 0,
      );
}

class SeedAuthor {
  final String name;
  final String? bio;
  final String? deathYear;

  const SeedAuthor({required this.name, this.bio, this.deathYear});

  Map<String, dynamic> toJson() => {'name': name, 'bio': bio, 'deathYear': deathYear};

  factory SeedAuthor.fromJson(Map<String, dynamic> j) =>
      SeedAuthor(name: j['name'] as String, bio: j['bio'] as String?, deathYear: j['deathYear'] as String?);
}

class SeedPublisher {
  final String name;
  const SeedPublisher({required this.name});

  Map<String, dynamic> toJson() => {'name': name};
  factory SeedPublisher.fromJson(Map<String, dynamic> j) =>
      SeedPublisher(name: j['name'] as String);
}

/// مجلد يُحدَّد بمساره الكامل (اسم القسم + سلسلة أسماء المجلدات الأب)
/// بدل معرّف رقمي، لأن المعرّفات الرقمية تختلف من جهاز لآخر.
class SeedFolder {
  final String sectionName;
  final List<String> parentPath; // فارغة = مجلد رئيسي مباشرة داخل القسم
  final String name;
  final int sortOrder;

  const SeedFolder({
    required this.sectionName,
    required this.parentPath,
    required this.name,
    required this.sortOrder,
  });

  Map<String, dynamic> toJson() => {
        'sectionName': sectionName,
        'parentPath': parentPath,
        'name': name,
        'sortOrder': sortOrder,
      };

  factory SeedFolder.fromJson(Map<String, dynamic> j) => SeedFolder(
        sectionName: j['sectionName'] as String,
        parentPath: (j['parentPath'] as List).cast<String>(),
        name: j['name'] as String,
        sortOrder: j['sortOrder'] as int? ?? 0,
      );
}

class SeedBook {
  final String sectionName;
  final List<String> folderPath; // فارغة = الكتاب مباشرة داخل القسم
  final String? authorName;
  final String? publisherName;
  final String title;
  final String? description;
  final String? edition;
  final String? remoteUrl; // رابط تنزيل PDF الذي يستضيفه الأدمن
  final String? keywords;

  const SeedBook({
    required this.sectionName,
    required this.folderPath,
    required this.title,
    this.authorName,
    this.publisherName,
    this.description,
    this.edition,
    this.remoteUrl,
    this.keywords,
  });

  Map<String, dynamic> toJson() => {
        'sectionName': sectionName,
        'folderPath': folderPath,
        'authorName': authorName,
        'publisherName': publisherName,
        'title': title,
        'description': description,
        'edition': edition,
        'remoteUrl': remoteUrl,
        'keywords': keywords,
      };

  factory SeedBook.fromJson(Map<String, dynamic> j) => SeedBook(
        sectionName: j['sectionName'] as String,
        folderPath: (j['folderPath'] as List).cast<String>(),
        authorName: j['authorName'] as String?,
        publisherName: j['publisherName'] as String?,
        title: j['title'] as String,
        description: j['description'] as String?,
        edition: j['edition'] as String?,
        remoteUrl: j['remoteUrl'] as String?,
        keywords: j['keywords'] as String?,
      );
}
