import 'package:shared_preferences/shared_preferences.dart';

/// طبقة رقيقة فوق SharedPreferences، حتى لا تتكرر أسماء المفاتيح ومنطق
/// القراءة/الكتابة في كل Notifier على حدة (وضع السمة، إعدادات القراءة...).
class LocalPrefsStore {
  static const _themeModeKey = 'settings.themeMode';
  static const _readerModeKey = 'settings.reader.mode';
  static const _readerFontSizeKey = 'settings.reader.fontSize';
  static const _readerKeepScreenOnKey = 'settings.reader.keepScreenOn';

  Future<SharedPreferences> get _prefs => SharedPreferences.getInstance();

  Future<String?> getThemeMode() async => (await _prefs).getString(_themeModeKey);
  Future<void> setThemeMode(String value) async =>
      (await _prefs).setString(_themeModeKey, value);

  Future<String?> getReaderMode() async => (await _prefs).getString(_readerModeKey);
  Future<void> setReaderMode(String value) async =>
      (await _prefs).setString(_readerModeKey, value);

  Future<double?> getReaderFontSize() async =>
      (await _prefs).getDouble(_readerFontSizeKey);
  Future<void> setReaderFontSize(double value) async =>
      (await _prefs).setDouble(_readerFontSizeKey, value);

  Future<bool?> getReaderKeepScreenOn() async =>
      (await _prefs).getBool(_readerKeepScreenOnKey);
  Future<void> setReaderKeepScreenOn(bool value) async =>
      (await _prefs).setBool(_readerKeepScreenOnKey, value);
}
