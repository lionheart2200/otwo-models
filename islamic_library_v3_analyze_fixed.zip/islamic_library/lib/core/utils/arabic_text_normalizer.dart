/// يطبّق تطبيع موحّد على النص العربي، يُستخدم في مرحلتين:
/// 1) عند فهرسة نص صفحات PDF (قبل إدخالها في FTS5).
/// 2) عند تنفيذ استعلام بحث المستخدم.
///
/// كلا الطرفين يجب أن يمرّا بنفس الدالة بالضبط، وإلا لن تتطابق النتائج.
class ArabicTextNormalizer {
  ArabicTextNormalizer._();

  // نطاق يونيكود لعلامات التشكيل العربية (الحركات، السكون، الشدة، التنوين)
  static final RegExp _diacritics = RegExp(
    r'[\u064B-\u065F\u0610-\u061A\u06D6-\u06DC\u06DF-\u06E8\u06EA-\u06ED\u0670]',
  );

  // إطالة الحروف (التطويل / الكشيدة) مثل "الللللـه"
  static final RegExp _tatweel = RegExp(r'\u0640');

  // أي رمز غير حرف عربي/لاتيني/رقم/مسافة (علامات ترقيم، رموز خاصة)
  static final RegExp _punctuation = RegExp(
    r'''[^\u0600-\u06FF\u0750-\u077Fa-zA-Z0-9\s]''',
  );

  static final RegExp _multiSpace = RegExp(r'\s+');

  /// التطبيع الكامل: يُستخدم في الفهرسة وفي البحث الفعلي (Query) معًا.
  static String normalize(String input) {
    var text = input;

    // 1) إزالة التشكيل
    text = text.replaceAll(_diacritics, '');

    // 2) إزالة التطويل
    text = text.replaceAll(_tatweel, '');

    // 3) توحيد أشكال الألف: أ إ آ ٱ -> ا
    text = text.replaceAll(RegExp('[أإآٱ]'), 'ا');

    // 4) توحيد الياء: ى -> ي
    text = text.replaceAll('ى', 'ي');

    // 5) توحيد التاء المربوطة: ة -> ه
    // (اختياري ومفيد لأن كثيرًا من المستخدمين يخطئون بينهما أثناء الكتابة)
    text = text.replaceAll('ة', 'ه');

    // 6) توحيد الهمزات المفردة (ؤ ئ ء) إلى شكل مبسّط عند الحاجة للبحث المرن
    // نُبقيها كما هي افتراضيًا لتفادي فقدان الدقة، ويمكن تفعيل هذا السطر
    // إذا رغبت في بحث أكثر تسامحًا:
    // text = text.replaceAll(RegExp('[ؤئ]'), 'ء');

    // 7) إزالة علامات الترقيم والرموز
    text = text.replaceAll(_punctuation, ' ');

    // 8) توحيد المسافات المتعددة إلى مسافة واحدة + trim
    text = text.replaceAll(_multiSpace, ' ').trim();

    // 9) تحويل الحروف اللاتينية (إن وجدت أسماء أعلام لاتينية) لحالة صغيرة
    text = text.toLowerCase();

    return text;
  }

  /// يجهّز استعلام المستخدم لصياغة FTS5 MATCH:
  /// - يطبّع النص أولًا بنفس دالة normalize
  /// - يضع كل كلمة بين علامتي اقتباس لتفادي رموز FTS5 الخاصة (مثل - أو *)
  /// - إن كانت أكثر من كلمة، يبحث عن تقاربها (AND ضمني عبر الفراغ في FTS5)
  static String buildMatchQuery(String rawQuery, {bool prefixSearch = false}) {
    final normalized = normalize(rawQuery);
    if (normalized.isEmpty) return '';

    final words = normalized.split(' ').where((w) => w.isNotEmpty);
    final tokens = words.map((w) {
      final escaped = w.replaceAll('"', '""');
      return prefixSearch ? '"$escaped"*' : '"$escaped"';
    });

    return tokens.join(' ');
  }
}
