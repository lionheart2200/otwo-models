import 'package:drift/drift.dart';
import 'books_table.dart';

/// المفضلة
class Favorites extends Table {
  IntColumn get bookId =>
      integer().references(Books, #id, onDelete: KeyAction.cascade)();
  DateTimeColumn get addedAt => dateTime().withDefault(currentDateAndTime)();

  @override
  Set<Column> get primaryKey => {bookId};
}

/// قوائم شخصية ينشئها المستخدم (مثل "مجلد شخصي جديد" في المثال المطلوب)
class PersonalLists extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get name => text().withLength(min: 1, max: 100)();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
}

/// ربط الكتب بالقوائم الشخصية (علاقة متعدد لمتعدد)
class PersonalListItems extends Table {
  IntColumn get listId =>
      integer().references(PersonalLists, #id, onDelete: KeyAction.cascade)();
  IntColumn get bookId =>
      integer().references(Books, #id, onDelete: KeyAction.cascade)();

  @override
  Set<Column> get primaryKey => {listId, bookId};
}

/// العلامات المرجعية (Bookmarks) - يمكن أن يكون للكتاب عدة علامات
class Bookmarks extends Table {
  IntColumn get id => integer().autoIncrement()();
  IntColumn get bookId =>
      integer().references(Books, #id, onDelete: KeyAction.cascade)();
  IntColumn get pageNumber => integer()();
  TextColumn get label => text().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
}

/// ملاحظات وتظليل النصوص
class Notes extends Table {
  IntColumn get id => integer().autoIncrement()();
  IntColumn get bookId =>
      integer().references(Books, #id, onDelete: KeyAction.cascade)();
  IntColumn get pageNumber => integer()();
  TextColumn get highlightedText => text().nullable()();
  TextColumn get noteContent => text().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
}

/// اقتباسات محفوظة من المستخدم (بند إضافي 4)
class SavedQuotes extends Table {
  IntColumn get id => integer().autoIncrement()();
  IntColumn get bookId =>
      integer().references(Books, #id, onDelete: KeyAction.cascade)();
  IntColumn get pageNumber => integer()();
  TextColumn get quoteText => text()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
}

/// سجل عمليات البحث الأخيرة + الاقتراحات
class SearchHistory extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get query => text().withLength(min: 1, max: 200)();
  /// نطاق البحث وقت التنفيذ: `all` / `section:id` / `book:id`
  TextColumn get scope => text().withDefault(const Constant('all'))();
  IntColumn get resultsCount => integer().withDefault(const Constant(0))();
  DateTimeColumn get searchedAt => dateTime().withDefault(currentDateAndTime)();
}
