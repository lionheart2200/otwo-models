import 'package:drift/drift.dart';
import 'sections_table.dart';
import 'folders_table.dart';
import 'authors_table.dart';

/// حالة فهرسة الكتاب لدعم البحث داخل PDF (بند ثالثًا في الطلب)
enum IndexingStatus {
  notIndexed, // لم تبدأ الفهرسة بعد
  indexing, // جارٍ استخراج النص وإدخاله في FTS5
  indexed, // مفهرس بالكامل - قابل للبحث فيه
  needsOcr, // ملف صور ممسوحة ضوئيًا - لا يحتوي نصًا حقيقيًا (ميزة مستقبلية)
  failed, // فشلت الفهرسة (ملف تالف مثلًا)
}

class Books extends Table {
  IntColumn get id => integer().autoIncrement()();

  IntColumn get sectionId =>
      integer().references(Sections, #id, onDelete: KeyAction.cascade)();

  /// null يعني الكتاب موجود مباشرة داخل القسم بدون مجلد فرعي
  IntColumn get folderId =>
      integer().nullable().references(Folders, #id, onDelete: KeyAction.setNull)();

  IntColumn get authorId =>
      integer().nullable().references(Authors, #id, onDelete: KeyAction.setNull)();

  IntColumn get publisherId =>
      integer().nullable().references(Publishers, #id, onDelete: KeyAction.setNull)();

  TextColumn get title => text().withLength(min: 1, max: 300)();
  TextColumn get description => text().nullable()();
  TextColumn get edition => text().nullable()();
  TextColumn get keywords => text().nullable()(); // مفصولة بفواصل، تُستخدم في البحث بالعنوان

  /// المسار المحلي الفعلي لملف الـ PDF بعد التنزيل. null إذا لم يُنزَّل بعد.
  TextColumn get localFilePath => text().nullable()();

  /// رابط التنزيل عن بعد (يُستخدم عند التوسع لاحقًا لمصدر محتوى مركزي)
  TextColumn get remoteUrl => text().nullable()();

  TextColumn get coverImagePath => text().nullable()();

  IntColumn get pageCount => integer().nullable()();
  IntColumn get fileSizeBytes => integer().nullable()();

  /// حالة الفهرسة كنص (Drift يخزّن الـ Enum كنص عبر textEnum)
  TextColumn get indexingStatus => textEnum<IndexingStatus>()
      .withDefault(Constant(IndexingStatus.notIndexed.name))();

  BoolColumn get isDownloaded => boolean().withDefault(const Constant(false))();

  IntColumn get readCount => integer().withDefault(const Constant(0))();

  DateTimeColumn get addedAt => dateTime().withDefault(currentDateAndTime)();
}
