import 'package:drift/drift.dart';
import 'books_table.dart';

class ReadingProgress extends Table {
  /// كتاب واحد له سجل تقدم واحد فقط
  IntColumn get bookId =>
      integer().references(Books, #id, onDelete: KeyAction.cascade)();

  IntColumn get lastPageRead => integer().withDefault(const Constant(1))();
  RealColumn get progressPercent => real().withDefault(const Constant(0))();

  /// إجمالي وقت القراءة بالثواني (لإحصائيات القراءة - بند إضافي 6)
  IntColumn get totalReadingSeconds => integer().withDefault(const Constant(0))();

  DateTimeColumn get lastReadAt => dateTime().withDefault(currentDateAndTime)();

  @override
  Set<Column> get primaryKey => {bookId};
}
