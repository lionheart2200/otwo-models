import 'package:drift/drift.dart';

/// الأقسام الرئيسية للتطبيق (القرآن، الحديث، الفقه، ...).
/// قابلة للإضافة/التعديل من قبل المستخدم أو من لوحة تحكم مستقبلية
/// دون الحاجة لتعديل الكود — لهذا هي جدول عادي وليست Enum ثابتة.
class Sections extends Table {
  IntColumn get id => integer().autoIncrement()();

  /// اسم القسم كما يظهر للمستخدم (عربي)
  TextColumn get name => text().withLength(min: 1, max: 100)();

  /// وصف مختصر اختياري للقسم
  TextColumn get description => text().nullable()();

  /// اسم الأيقونة (Material Icon name أو مسار SVG)
  TextColumn get iconName => text().nullable()();

  /// ترتيب العرض في الشاشة الرئيسية / قائمة الأقسام
  IntColumn get sortOrder => integer().withDefault(const Constant(0))();

  /// هل القسم مفعّل ويظهر للمستخدم
  BoolColumn get isActive => boolean().withDefault(const Constant(true))();

  DateTimeColumn get createdAt =>
      dateTime().withDefault(currentDateAndTime)();
}
