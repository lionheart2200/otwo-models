import 'package:drift/drift.dart';
import 'sections_table.dart';

/// مجلدات هرمية غير محدودة العمق داخل كل قسم.
/// عبر parentFolderId (Self-Reference) يمكن إنشاء أي عدد من المستويات:
/// الفقه -> فقه العبادات -> الصلاة -> أحكام السهو ...
class Folders extends Table {
  IntColumn get id => integer().autoIncrement()();

  IntColumn get sectionId =>
      integer().references(Sections, #id, onDelete: KeyAction.cascade)();

  /// المجلد الأب. null يعني أنه مجلد رئيسي داخل القسم مباشرة.
  IntColumn get parentFolderId => integer()
      .nullable()
      .references(Folders, #id, onDelete: KeyAction.cascade)();

  TextColumn get name => text().withLength(min: 1, max: 150)();

  IntColumn get sortOrder => integer().withDefault(const Constant(0))();

  DateTimeColumn get createdAt =>
      dateTime().withDefault(currentDateAndTime)();
}
