import 'package:drift/drift.dart';

class Authors extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get name => text().withLength(min: 1, max: 150)();
  TextColumn get bio => text().nullable()();
  /// تاريخ الوفاة الهجري/الميلادي كنص حر (مرن لعالم قديم أو معاصر)
  TextColumn get deathYear => text().nullable()();
}

class Publishers extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get name => text().withLength(min: 1, max: 150)();
}
