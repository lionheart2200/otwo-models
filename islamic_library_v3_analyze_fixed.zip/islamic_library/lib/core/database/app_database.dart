import 'package:drift/drift.dart';
import 'package:drift_flutter/drift_flutter.dart';

import 'tables/sections_table.dart';
import 'tables/folders_table.dart';
import 'tables/authors_table.dart';
import 'tables/books_table.dart';
import 'tables/reading_progress_table.dart';
import 'tables/user_library_tables.dart';

part 'app_database.g.dart';

/// اسم جدول الـ FTS5 الافتراضي. لا يُعرَّف كـ Drift Table عادي
/// لأن SQLite Virtual Tables لها بنية خاصة (bm25, tokenize...)
/// ننشئه عبر SQL خام في onCreate/onUpgrade لضمان دقة الصياغة 100%.
const String pagesFtsTableName = 'pages_fts';

const String _createPagesFtsSql = '''
CREATE VIRTUAL TABLE IF NOT EXISTS $pagesFtsTableName USING fts5(
  normalized_text,
  original_text UNINDEXED,
  book_id UNINDEXED,
  page_number UNINDEXED,
  tokenize = 'unicode61 remove_diacritics 2'
);
''';

@DriftDatabase(
  tables: [
    Sections,
    Folders,
    Authors,
    Publishers,
    Books,
    ReadingProgress,
    Favorites,
    PersonalLists,
    PersonalListItems,
    Bookmarks,
    Notes,
    SavedQuotes,
    SearchHistory,
  ],
)
class AppDatabase extends _$AppDatabase {
  AppDatabase() : super(_openConnection());

  @override
  int get schemaVersion => 1;

  @override
  MigrationStrategy get migration => MigrationStrategy(
        onCreate: (Migrator m) async {
          await m.createAll();
          await customStatement(_createPagesFtsSql);
        },
        onUpgrade: (Migrator m, int from, int to) async {
          // عند إضافة أقسام/جداول مستقبلية تُضاف هنا خطوات الترحيل
          // مثال: if (from < 2) { await m.addColumn(...); }
        },
        beforeOpen: (details) async {
          await customStatement('PRAGMA foreign_keys = ON');
        },
      );

  // ---------------------------------------------------------------------
  // عمليات FTS5 اليدوية (Drift لا يولّد كودًا لجداول Virtual تلقائيًا)
  // ---------------------------------------------------------------------

  /// إدخال دفعة صفحات كتاب واحد في فهرس البحث بعملية واحدة (Batch)
  /// لتجنّب بطء الإدخال صفحة بصفحة على كتب بمئات الصفحات.
  Future<void> insertPagesBatch(List<PageIndexEntry> pages) async {
    if (pages.isEmpty) return;
    await batch((b) {
      for (final page in pages) {
        b.customInsert(
          'INSERT INTO $pagesFtsTableName '
          '(normalized_text, original_text, book_id, page_number) '
          'VALUES (?, ?, ?, ?)',
          variables: [
            Variable.withString(page.normalizedText),
            Variable.withString(page.originalText),
            Variable.withInt(page.bookId),
            Variable.withInt(page.pageNumber),
          ],
        );
      }
    });
  }

  /// حذف كل صفحات كتاب من الفهرس (عند إعادة الفهرسة أو حذف الكتاب)
  Future<void> deleteBookFromIndex(int bookId) async {
    await customStatement(
      'DELETE FROM $pagesFtsTableName WHERE book_id = ?',
      [bookId],
    );
  }
}

/// عنصر واحد يمثّل صفحة قبل إدخالها في الفهرس
class PageIndexEntry {
  final int bookId;
  final int pageNumber;
  final String originalText;
  final String normalizedText;

  const PageIndexEntry({
    required this.bookId,
    required this.pageNumber,
    required this.originalText,
    required this.normalizedText,
  });
}

QueryExecutor _openConnection() {
  return driftDatabase(
    name: 'islamic_library_db',
    native: const DriftNativeOptions(
      // يفعّل SQLite3 مع دعم FTS5 (متوفر افتراضيًا في sqlite3_flutter_libs)
      shareAcrossIsolates: true,
    ),
  );
}
