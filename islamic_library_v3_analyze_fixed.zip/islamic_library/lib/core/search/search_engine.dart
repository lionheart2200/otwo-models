import 'package:drift/drift.dart';

import '../database/app_database.dart';
import '../utils/arabic_text_normalizer.dart';
import 'models/search_result.dart';

/// الطبقة المسؤولة الوحيدة عن تنفيذ استعلامات البحث داخل محتوى PDF.
/// تعتمد بالكامل على SQLite FTS5 + bm25 (لا خوارزمية ترتيب يدوية).
class SearchEngine {
  final AppDatabase _db;

  SearchEngine(this._db);

  /// تنفيذ بحث كامل. يُستدعى من الواجهة بعد Debounce (300ms) حتى لا يُنفَّذ
  /// استعلام مع كل ضغطة مفتاح.
  Future<List<SearchResult>> search({
    required String query,
    SearchScope scope = const AllLibraryScope(),
    SearchFilters filters = const SearchFilters(),
  }) async {
    final matchQuery = ArabicTextNormalizer.buildMatchQuery(query);
    if (matchQuery.isEmpty) return [];

    final buffer = StringBuffer('''
      SELECT
        pages_fts.book_id      AS book_id,
        pages_fts.page_number  AS page_number,
        snippet(pages_fts, 0, '⟪', '⟫', '…', 14) AS snippet,
        bm25(pages_fts)        AS rank,
        books.title             AS book_title,
        sections.name           AS section_name,
        authors.name            AS author_name
      FROM pages_fts
      JOIN books    ON books.id = pages_fts.book_id
      JOIN sections ON sections.id = books.section_id
      LEFT JOIN authors ON authors.id = books.author_id
      WHERE pages_fts MATCH ?
    ''');

    final variables = <Variable>[Variable.withString(matchQuery)];

    switch (scope) {
      case AllLibraryScope():
        break;
      case SectionScope(sectionId: final id):
        buffer.write(' AND sections.id = ? ');
        variables.add(Variable.withInt(id));
      case BookScope(bookId: final id):
        buffer.write(' AND pages_fts.book_id = ? ');
        variables.add(Variable.withInt(id));
    }

    if (filters.authorId != null) {
      buffer.write(' AND books.author_id = ? ');
      variables.add(Variable.withInt(filters.authorId!));
    }

    buffer.write(' ORDER BY rank LIMIT ? ');
    variables.add(Variable.withInt(filters.maxResults));

    final rows = await _db
        .customSelect(
          buffer.toString(),
          variables: variables,
          readsFrom: {},
        )
        .get();

    return rows.map((row) {
      return SearchResult(
        bookId: row.read<int>('book_id'),
        bookTitle: row.read<String>('book_title'),
        authorName: row.readNullable<String>('author_name'),
        sectionName: row.read<String>('section_name'),
        pageNumber: row.read<int>('page_number'),
        snippet: row.read<String>('snippet'),
        matchedQuery: query,
        // bm25 في SQLite: كلما كانت القيمة أصغر (أكثر سلبية) زادت الصلة.
        // نعكس الإشارة كي تكون القيمة الأعلى = الأكثر صلة، وهو أسهل للاستهلاك
        // في الواجهة (مثلًا لعرض شريط صلة أو ترتيب تنازلي مباشر).
        relevanceScore: -row.read<double>('rank'),
      );
    }).toList();
  }

  /// عدد النتائج فقط (لعرض "X نتيجة" في الواجهة بسرعة دون تحميل كل البيانات)
  Future<int> countResults({
    required String query,
    SearchScope scope = const AllLibraryScope(),
  }) async {
    final matchQuery = ArabicTextNormalizer.buildMatchQuery(query);
    if (matchQuery.isEmpty) return 0;

    final buffer = StringBuffer('''
      SELECT COUNT(*) AS c FROM pages_fts WHERE pages_fts MATCH ?
    ''');
    final variables = <Variable>[Variable.withString(matchQuery)];

    switch (scope) {
      case AllLibraryScope():
        break;
      case SectionScope(sectionId: final id):
        buffer.write('''
          AND book_id IN (SELECT id FROM books WHERE section_id = ?)
        ''');
        variables.add(Variable.withInt(id));
      case BookScope(bookId: final id):
        buffer.write(' AND book_id = ? ');
        variables.add(Variable.withInt(id));
    }

    final row = await _db
        .customSelect(buffer.toString(), variables: variables)
        .getSingle();
    return row.read<int>('c');
  }

  /// حفظ عملية بحث في السجل (لعرض "آخر عمليات البحث" و"اقتراح كلمات سابقة")
  Future<void> saveToHistory(String query, String scopeLabel, int resultsCount) async {
    await _db.into(_db.searchHistory).insert(
          SearchHistoryCompanion.insert(
            query: query,
            scope: Value(scopeLabel),
            resultsCount: Value(resultsCount),
          ),
        );
  }

  /// آخر عمليات البحث (لعرضها في صفحة البحث عند فتحها فارغة)
  Future<List<String>> recentSearches({int limit = 10}) async {
    final query = _db.select(_db.searchHistory)
      ..orderBy([(t) => OrderingTerm.desc(t.searchedAt)])
      ..limit(limit);
    final rows = await query.get();
    // إزالة التكرار مع الحفاظ على الأحدث أولًا
    final seen = <String>{};
    final result = <String>[];
    for (final row in rows) {
      if (seen.add(row.query)) result.add(row.query);
    }
    return result;
  }
}
