/// نتيجة بحث واحدة داخل محتوى PDF
class SearchResult {
  final int bookId;
  final String bookTitle;
  final String? authorName;
  final String sectionName;
  final int pageNumber;

  /// مقتطف نصي يحيط بموضع الكلمة المطلوبة (Snippet)
  final String snippet;

  /// الكلمة/الجملة الأصلية التي بحث عنها المستخدم (لأغراض التمييز البصري
  /// Highlight في الواجهة)
  final String matchedQuery;

  /// درجة الصلة من bm25 (كلما كانت أقل كانت النتيجة أكثر صلة في FTS5،
  /// لذلك نعكسها هنا لتكون: كلما زادت القيمة زادت الصلة)
  final double relevanceScore;

  const SearchResult({
    required this.bookId,
    required this.bookTitle,
    required this.sectionName,
    required this.pageNumber,
    required this.snippet,
    required this.matchedQuery,
    required this.relevanceScore,
    this.authorName,
  });
}

/// نطاق تنفيذ البحث
sealed class SearchScope {
  const SearchScope();
}

class AllLibraryScope extends SearchScope {
  const AllLibraryScope();
}

class SectionScope extends SearchScope {
  final int sectionId;
  const SectionScope(this.sectionId);
}

class BookScope extends SearchScope {
  final int bookId;
  const BookScope(this.bookId);
}

/// خيارات فلترة إضافية للبحث المتقدم (بند ثامنًا)
class SearchFilters {
  final int? authorId;
  final int? sectionId;
  final int maxResults;

  const SearchFilters({
    this.authorId,
    this.sectionId,
    this.maxResults = 50,
  });
}
