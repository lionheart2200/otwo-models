import 'dart:convert';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// نتيجة محاولة تسجيل الدخول
enum LoginResult {
  success,
  wrongPassword,
  notAdminEmail, // البريد ليس بريد الأدمن، ولا يوجد نظام حسابات آخر محليًا
}

/// مصادقة محلية بسيطة لبريد أدمن واحد فقط (lionheart2200@gmail.com).
///
/// كيف تعمل:
/// - أول مرة يُدخِل فيها صاحب هذا البريد كلمة مرور، تُعتبر "تسجيلًا" لها:
///   تُجزَّأ (SHA-256 + Salt عشوائي) وتُحفظ محليًا عبر SharedPreferences.
/// - أي محاولة لاحقة بنفس البريد تُقارَن بالتجزئة المحفوظة.
/// - أي بريد آخر غير بريد الأدمن يُرفض فورًا (notAdminEmail) لأنه لا يوجد
///   نظام حسابات عام محليًا أصلًا — هذا تطبيق أدمن واحد فقط حاليًا.
///
/// ملاحظة أمان صادقة: هذا التحقق يحدث بالكامل على جهاز المستخدم نفسه
/// (لا خادم يتحقق منه). يكفي تمامًا لمنع المستخدم العادي من الوصول
/// للوحة الإدارة بالخطأ أو بمحاولة تخمين بسيطة، لكنه لا يوازي حماية
/// خادم حقيقي ضد مبرمج متمرس يُعدّل الـ APK/IPA مباشرة. هذا مقبول في
/// هذه المرحلة لأن لا يوجد محتوى حسّاس أو بيانات مستخدمين آخرين مهددة —
/// أقصى ضرر ممكن هو أن يرى شخص واجهة الإدارة على تطبيقه المحلي هو فقط.
class AdminAuthService {
  static const String adminEmail = 'lionheart2200@gmail.com';

  static const _passwordHashKey = 'admin.passwordHash';
  static const _saltKey = 'admin.salt';
  static const _isLoggedInKey = 'admin.isLoggedIn';

  Future<SharedPreferences> get _prefs => SharedPreferences.getInstance();

  bool isAdminEmail(String email) =>
      email.trim().toLowerCase() == adminEmail.toLowerCase();

  Future<bool> hasPasswordBeenSet() async {
    final prefs = await _prefs;
    return prefs.containsKey(_passwordHashKey);
  }

  String _generateSalt() {
    final random = Random.secure();
    final bytes = List<int>.generate(16, (_) => random.nextInt(256));
    return base64Url.encode(bytes);
  }

  String _hash(String password, String salt) {
    final bytes = utf8.encode('$salt:$password');
    return sha256.convert(bytes).toString();
  }

  /// محاولة تسجيل الدخول. إن كان البريد بريد الأدمن ولم تُحفظ كلمة مرور
  /// من قبل، تُسجَّل كلمة المرور المُدخَلة الآن كأول كلمة مرور رسمية.
  Future<LoginResult> login({required String email, required String password}) async {
    if (!isAdminEmail(email)) return LoginResult.notAdminEmail;

    final prefs = await _prefs;
    final hasPassword = prefs.containsKey(_passwordHashKey);

    if (!hasPassword) {
      // أول تسجيل دخول لبريد الأدمن = تسجيل كلمة المرور
      final salt = _generateSalt();
      await prefs.setString(_saltKey, salt);
      await prefs.setString(_passwordHashKey, _hash(password, salt));
      await prefs.setBool(_isLoggedInKey, true);
      return LoginResult.success;
    }

    final salt = prefs.getString(_saltKey)!;
    final storedHash = prefs.getString(_passwordHashKey)!;
    final attemptHash = _hash(password, salt);

    if (attemptHash == storedHash) {
      await prefs.setBool(_isLoggedInKey, true);
      return LoginResult.success;
    }
    return LoginResult.wrongPassword;
  }

  Future<void> logout() async {
    final prefs = await _prefs;
    await prefs.setBool(_isLoggedInKey, false);
  }

  Future<bool> restoreSession() async {
    final prefs = await _prefs;
    return prefs.getBool(_isLoggedInKey) ?? false;
  }

  /// لتغيير كلمة المرور من داخل لوحة الإعدادات لاحقًا إن رغبت.
  Future<bool> changePassword({
    required String currentPassword,
    required String newPassword,
  }) async {
    final prefs = await _prefs;
    final salt = prefs.getString(_saltKey);
    final storedHash = prefs.getString(_passwordHashKey);
    if (salt == null || storedHash == null) return false;
    if (_hash(currentPassword, salt) != storedHash) return false;

    final newSalt = _generateSalt();
    await prefs.setString(_saltKey, newSalt);
    await prefs.setString(_passwordHashKey, _hash(newPassword, newSalt));
    return true;
  }
}
