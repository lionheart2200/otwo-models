import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../providers/app_providers.dart';
import '../../widgets/book_card.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final continueReading = ref.watch(continueReadingProvider);
    final recentlyAdded = ref.watch(recentlyAddedProvider);
    final mostRead = ref.watch(mostReadProvider);
    final dailyQuote = ref.watch(dailyQuoteProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('المكتبة الإسلامية الشاملة')),
      body: RefreshIndicator(
        onRefresh: () async {
          ref.invalidate(continueReadingProvider);
          ref.invalidate(recentlyAddedProvider);
          ref.invalidate(mostReadProvider);
        },
        child: ListView(
          padding: const EdgeInsets.symmetric(vertical: 16),
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: _SearchEntryField(onTap: () => context.push('/search')),
            ),
            const SizedBox(height: 20),

            dailyQuote.when(
              data: (quote) => quote == null
                  ? const SizedBox.shrink()
                  : _DailyQuoteCard(quote: quote),
              loading: () => const SizedBox.shrink(),
              error: (_, __) => const SizedBox.shrink(),
            ),
            const SizedBox(height: 12),

            continueReading.when(
              data: (books) => BookRowSection(title: 'تابع القراءة', books: books),
              loading: () => const SizedBox.shrink(),
              error: (_, __) => const SizedBox.shrink(),
            ),
            recentlyAdded.when(
              data: (books) => BookRowSection(title: 'أضيف حديثًا', books: books),
              loading: () => const SizedBox.shrink(),
              error: (_, __) => const SizedBox.shrink(),
            ),
            mostRead.when(
              data: (books) => BookRowSection(title: 'الأكثر قراءة', books: books),
              loading: () => const SizedBox.shrink(),
              error: (_, __) => const SizedBox.shrink(),
            ),
          ],
        ),
      ),
    );
  }
}

/// حقل بحث وهمي (Entry Point) ينقل المستخدم لشاشة البحث الفعلية عند الضغط،
/// بدل تكرار منطق TextField مرتين.
class _SearchEntryField extends StatelessWidget {
  final VoidCallback onTap;
  const _SearchEntryField({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          children: [
            const Icon(Icons.search),
            const SizedBox(width: 10),
            Text(
              'ابحث في القرآن والحديث والفقه...',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ],
        ),
      ),
    );
  }
}

/// بطاقة الاقتباس/الفائدة اليومية — تعرض نصًا حقيقيًا محفوظًا من مكتبة
/// المستخدم مع مصدره (اسم الكتاب ورقم الصفحة)، ويمكن الضغط عليها للانتقال
/// مباشرة لموضع الاقتباس داخل الكتاب.
class _DailyQuoteCard extends StatelessWidget {
  final DailyQuote quote;
  const _DailyQuoteCard({required this.quote});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Card(
        color: Theme.of(context).colorScheme.secondaryContainer,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(Icons.format_quote,
                      color: Theme.of(context).colorScheme.onSecondaryContainer),
                  const SizedBox(width: 8),
                  Text('فائدة اليوم',
                      style: Theme.of(context).textTheme.bodySmall),
                ],
              ),
              const SizedBox(height: 8),
              Text(quote.text, style: Theme.of(context).textTheme.bodyMedium),
              const SizedBox(height: 8),
              Text(
                '— ${quote.bookTitle}، صفحة ${quote.pageNumber}',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
