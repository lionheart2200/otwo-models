import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../providers/theme_provider.dart';
import '../auth/providers/auth_providers.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final themeMode = ref.watch(themeModeProvider);
    final themeNotifier = ref.read(themeModeProvider.notifier);
    final session = ref.watch(adminSessionProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView(
        children: [
          const _SectionHeader('الحساب'),
          if (session.isLoggedIn) ...[
            const ListTile(
              leading: Icon(Icons.verified_user_outlined),
              title: Text('مسجَّل الدخول كأدمن'),
            ),
            ListTile(
              leading: const Icon(Icons.admin_panel_settings_outlined),
              title: const Text('لوحة الإدارة'),
              trailing: const Icon(Icons.chevron_left),
              onTap: () => context.push('/admin'),
            ),
            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text('تسجيل الخروج'),
              onTap: () => ref.read(adminSessionProvider.notifier).logout(),
            ),
          ] else
            ListTile(
              leading: const Icon(Icons.login),
              title: const Text('تسجيل الدخول'),
              subtitle: const Text('اختياري — يمكنك تصفح المكتبة بدونه'),
              onTap: () => context.push('/login'),
            ),
          const Divider(),
          const _SectionHeader('المظهر'),
          RadioGroup<ThemeMode>(
            groupValue: themeMode,
            onChanged: (m) {
              if (m != null) themeNotifier.setMode(m);
            },
            child: const Column(
              children: [
                RadioListTile<ThemeMode>(title: Text('فاتح'), value: ThemeMode.light),
                RadioListTile<ThemeMode>(title: Text('داكن'), value: ThemeMode.dark),
                RadioListTile<ThemeMode>(
                  title: Text('حسب النظام'),
                  value: ThemeMode.system,
                ),
              ],
            ),
          ),
          const Divider(),
          const _SectionHeader('الإشعارات'),
          SwitchListTile(
            title: const Text('تذكير يومي بالقراءة'),
            value: false,
            onChanged: null, // مربوط بنظام الإشعارات في مرحلة قادمة
          ),
          const Divider(),
          const _SectionHeader('عن التطبيق'),
          const ListTile(
            title: Text('المكتبة الإسلامية الشاملة'),
            subtitle: Text('الإصدار 0.1.0 — مرحلة تطوير'),
          ),
        ],
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader(this.title);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
      child: Text(
        title,
        style: Theme.of(context)
            .textTheme
            .titleMedium
            ?.copyWith(color: Theme.of(context).colorScheme.primary),
      ),
    );
  }
}
