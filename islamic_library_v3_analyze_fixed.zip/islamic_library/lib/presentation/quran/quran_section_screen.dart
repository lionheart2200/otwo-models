import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../app/theme/app_colors.dart';
import '../providers/app_providers.dart';

/// شاشة مميزة لقسم "القرآن الكريم" (بند تاسعًا في الطلب) — نفس بيانات
/// المجلدات/الكتب الحقيقية من قاعدة البيانات، لكن بواجهة مختلفة بصريًا
/// عن باقي الأقسام (Header مميز + شبكة تصنيفات بدل قائمة عادية).
class QuranSectionScreen extends ConsumerWidget {
  final int sectionId;
  const QuranSectionScreen({super.key, required this.sectionId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final key = (sectionId: sectionId, folderId: null);
    final contentsAsync = ref.watch(folderContentsProvider(key));

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 160,
            pinned: true,
            backgroundColor: AppColors.primary,
            flexibleSpace: FlexibleSpaceBar(
              title: const Text('القرآن الكريم'),
              background: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [AppColors.primaryDark, AppColors.primary],
                    begin: Alignment.topRight,
                    end: Alignment.bottomLeft,
                  ),
                ),
                child: const Center(
                  child: Icon(Icons.menu_book, color: Colors.white24, size: 64),
                ),
              ),
            ),
          ),
          contentsAsync.when(
            data: (contents) {
              final items = [...contents.folders, ...contents.books];
              if (items.isEmpty) {
                return const SliverFillRemaining(
                  child: Center(child: Text('لا يوجد محتوى بعد')),
                );
              }
              return SliverPadding(
                padding: const EdgeInsets.all(16),
                sliver: SliverGrid(
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    mainAxisSpacing: 12,
                    crossAxisSpacing: 12,
                    childAspectRatio: 1.5,
                  ),
                  delegate: SliverChildBuilderDelegate(
                    (context, i) {
                      if (i < contents.folders.length) {
                        final folder = contents.folders[i];
                        return _QuranCategoryCard(
                          title: folder.name,
                          icon: Icons.folder_outlined,
                          onTap: () => context.push(
                            '/sections/$sectionId/folder/${folder.id}',
                            extra: folder.name,
                          ),
                        );
                      }
                      final book = contents.books[i - contents.folders.length];
                      return _QuranCategoryCard(
                        title: book.title,
                        icon: Icons.picture_as_pdf_outlined,
                        onTap: () => context.push('/book/${book.id}'),
                      );
                    },
                    childCount: items.length,
                  ),
                ),
              );
            },
            loading: () => const SliverFillRemaining(
              child: Center(child: CircularProgressIndicator()),
            ),
            error: (e, _) => SliverFillRemaining(
              child: Center(child: Text('حدث خطأ: $e')),
            ),
          ),
        ],
      ),
    );
  }
}

class _QuranCategoryCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final VoidCallback onTap;

  const _QuranCategoryCard({
    required this.title,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Icon(icon, color: AppColors.primary),
              const SizedBox(height: 8),
              Text(
                title,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
