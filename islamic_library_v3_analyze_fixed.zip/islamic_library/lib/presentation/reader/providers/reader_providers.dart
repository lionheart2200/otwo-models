import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/legacy.dart';

import '../../../core/storage/local_prefs_store.dart';
import '../../providers/app_providers.dart' show localPrefsStoreProvider;

enum ReaderMode { day, night, sepia }

class ReaderSettings {
  final ReaderMode mode;
  final double fontSize;
  final double brightness; // 0.0 - 1.0، يُستخدم فقط إن أردنا التحكم اليدوي
  final bool keepScreenOn;

  const ReaderSettings({
    this.mode = ReaderMode.day,
    this.fontSize = 18,
    this.brightness = 1.0,
    this.keepScreenOn = true,
  });

  ReaderSettings copyWith({
    ReaderMode? mode,
    double? fontSize,
    double? brightness,
    bool? keepScreenOn,
  }) {
    return ReaderSettings(
      mode: mode ?? this.mode,
      fontSize: fontSize ?? this.fontSize,
      brightness: brightness ?? this.brightness,
      keepScreenOn: keepScreenOn ?? this.keepScreenOn,
    );
  }
}

class ReaderSettingsNotifier extends StateNotifier<ReaderSettings> {
  final LocalPrefsStore _store;

  ReaderSettingsNotifier(this._store) : super(const ReaderSettings()) {
    _loadSaved();
  }

  Future<void> _loadSaved() async {
    final mode = await _store.getReaderMode();
    final fontSize = await _store.getReaderFontSize();
    final keepScreenOn = await _store.getReaderKeepScreenOn();

    state = state.copyWith(
      mode: mode != null
          ? ReaderMode.values.firstWhere((m) => m.name == mode, orElse: () => ReaderMode.day)
          : null,
      fontSize: fontSize,
      keepScreenOn: keepScreenOn,
    );
  }

  void setMode(ReaderMode mode) {
    state = state.copyWith(mode: mode);
    _store.setReaderMode(mode.name);
  }

  void setFontSize(double size) {
    final clamped = size.clamp(12, 32).toDouble();
    state = state.copyWith(fontSize: clamped);
    _store.setReaderFontSize(clamped);
  }

  void toggleKeepScreenOn() {
    final newValue = !state.keepScreenOn;
    state = state.copyWith(keepScreenOn: newValue);
    _store.setReaderKeepScreenOn(newValue);
  }
}

final readerSettingsProvider =
    StateNotifierProvider<ReaderSettingsNotifier, ReaderSettings>((ref) {
  return ReaderSettingsNotifier(ref.watch(localPrefsStoreProvider));
});

/// لوحة إعدادات القراءة (Bottom Sheet) التي يفتحها زر "Text Fields" في القارئ
class ReaderSettingsSheet extends ConsumerWidget {
  const ReaderSettingsSheet({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(readerSettingsProvider);
    final notifier = ref.read(readerSettingsProvider.notifier);

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('إعدادات القراءة', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 16),

            Text('وضع العرض'),
            const SizedBox(height: 8),
            SegmentedButton<ReaderMode>(
              segments: const [
                ButtonSegment(value: ReaderMode.day, label: Text('نهاري')),
                ButtonSegment(value: ReaderMode.sepia, label: Text('سيبيا')),
                ButtonSegment(value: ReaderMode.night, label: Text('ليلي')),
              ],
              selected: {settings.mode},
              onSelectionChanged: (s) => notifier.setMode(s.first),
            ),

            const SizedBox(height: 20),
            Text('حجم الخط'),
            Slider(
              value: settings.fontSize,
              min: 12,
              max: 32,
              divisions: 20,
              label: settings.fontSize.round().toString(),
              onChanged: notifier.setFontSize,
            ),

            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('إبقاء الشاشة مضاءة أثناء القراءة'),
              value: settings.keepScreenOn,
              onChanged: (_) => notifier.toggleKeepScreenOn(),
            ),
          ],
        ),
      ),
    );
  }
}
