import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:pdfrx/pdfrx.dart';

import '../../app/theme/app_colors.dart';
import '../../domain/entities/entities.dart';
import '../providers/app_providers.dart';
import 'providers/reader_providers.dart';

/// ملاحظة: تم التحقق من مطابقة الأصناف والدوال هنا (PdfViewerController،
/// PdfTextSearcher، pageTextMatchPaintCallback) للإصدار المثبت فعليًا عبر
/// `flutter analyze` الفعلي (التفاصيل في CORRECTIONS_PACKAGE_VERSIONS.md)،
/// مع ملاحظتين مهمتين تأكّدتا من نفس المصدر:
/// - `startTextSearch` دالة متزامنة (void)، وليست Future — لا تُسبَق بـ await.
/// - `PdfViewerController.pageNumber` قابلة لـ null فعليًا، وتُعامَل هنا
///   دائمًا بفحص صريح بدل الافتراض أنها غير فارغة.
///
/// شاشة القارئ. تُفتح بطريقتين:
/// 1) من المكتبة/الأقسام: bookId فقط -> يفتح من آخر صفحة محفوظة.
/// 2) من نتيجة بحث: bookId + initialPage + highlightQuery -> يفتح مباشرة
///    على صفحة النتيجة مع تمييز الكلمة المطلوبة (بند ثالثًا في الطلب).
class ReaderScreen extends ConsumerStatefulWidget {
  final int bookId;
  final int? initialPage;
  final String? highlightQuery;

  const ReaderScreen({
    super.key,
    required this.bookId,
    this.initialPage,
    this.highlightQuery,
  });

  @override
  ConsumerState<ReaderScreen> createState() => _ReaderScreenState();
}

class _ReaderScreenState extends ConsumerState<ReaderScreen>
    with WidgetsBindingObserver {
  late final PdfViewerController _controller;
  late final PdfTextSearcher _textSearcher;
  Timer? _readingTimer;
  int _secondsSinceLastSave = 0;
  bool _controlsVisible = true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _controller = PdfViewerController();
    _textSearcher = PdfTextSearcher(_controller)..addListener(_onSearchUpdated);
    _startReadingTimer();
  }

  /// يُعاد رسم الصفحة عند تغيّر نتائج البحث (مطابقة/فهرس مطابقة جديد)
  /// حتى يظهر التمييز البصري فور توفره، بدل انتظار إعادة رسم عرضية.
  void _onSearchUpdated() {
    if (mounted) setState(() {});
  }

  /// عدّاد بسيط لوقت القراءة يُحفظ كل 30 ثانية في تقدم القراءة
  /// (يغذّي إحصائيات القراءة المطلوبة في البند الإضافي 6).
  void _startReadingTimer() {
    _readingTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      _secondsSinceLastSave++;
      if (_secondsSinceLastSave >= 30) {
        _persistProgress(additionalSeconds: _secondsSinceLastSave);
        _secondsSinceLastSave = 0;
      }
    });
  }

  Future<void> _persistProgress({int additionalSeconds = 0}) async {
    final currentPage = _controller.isReady ? _controller.pageNumber : null;
    if (currentPage == null) return;

    final totalPages = _controller.pageCount;
    final percent = totalPages == 0 ? 0.0 : currentPage / totalPages;

    await ref.read(readingProgressRepositoryProvider).updateProgress(
          bookId: widget.bookId,
          lastPageRead: currentPage,
          progressPercent: percent,
          additionalSeconds: additionalSeconds,
        );
  }

  Future<void> _onDocumentReady() async {
    // تحديد صفحة الفتح: نتيجة بحث > آخر صفحة محفوظة > الصفحة الأولى
    if (widget.initialPage != null) {
      await _controller.goToPage(pageNumber: widget.initialPage!);
    } else {
      final progress =
          await ref.read(readingProgressRepositoryProvider).getProgress(widget.bookId);
      if (progress != null && progress.lastPageRead > 1) {
        await _controller.goToPage(pageNumber: progress.lastPageRead);
      }
    }

    // تمييز الكلمة المطلوبة إن جاءت من نتيجة بحث (دالة متزامنة void،
    // وليست Future — flutter analyze أكّد ذلك في هذا الإصدار من pdfrx)
    if (widget.highlightQuery != null && widget.highlightQuery!.trim().isNotEmpty) {
      _textSearcher.startTextSearch(widget.highlightQuery!);
    }

    await ref.read(booksRepositoryProvider).incrementReadCount(widget.bookId);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused || state == AppLifecycleState.detached) {
      _persistProgress(additionalSeconds: _secondsSinceLastSave);
      _secondsSinceLastSave = 0;
    }
  }

  @override
  void dispose() {
    _persistProgress(additionalSeconds: _secondsSinceLastSave);
    _readingTimer?.cancel();
    _textSearcher.removeListener(_onSearchUpdated);
    _textSearcher.dispose();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final readerSettings = ref.watch(readerSettingsProvider);
    final bookAsync = ref.watch(bookByIdProvider(widget.bookId));

    final backgroundColor = switch (readerSettings.mode) {
      ReaderMode.night => AppColors.readerNightBackground,
      ReaderMode.sepia => AppColors.readerSepiaBackground,
      ReaderMode.day => Colors.white,
    };

    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: _controlsVisible
          ? AppBar(
              backgroundColor: backgroundColor,
              title: bookAsync.when(
                data: (book) => Text(
                  book?.title ?? '',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                loading: () => const SizedBox.shrink(),
                error: (_, __) => const SizedBox.shrink(),
              ),
              actions: [
                IconButton(
                  icon: const Icon(Icons.bookmark_add_outlined),
                  tooltip: 'إضافة علامة مرجعية',
                  onPressed: _addBookmark,
                ),
                IconButton(
                  icon: const Icon(Icons.text_fields),
                  tooltip: 'إعدادات القراءة',
                  onPressed: () => _showReaderSettingsSheet(context),
                ),
              ],
            )
          : null,
      body: GestureDetector(
        onTap: () => setState(() => _controlsVisible = !_controlsVisible),
        child: bookAsync.when(
          data: (book) {
            if (book?.localFilePath == null) {
              return const Center(child: Text('الملف غير متوفر محليًا'));
            }
            return PdfViewer.file(
              book!.localFilePath!,
              controller: _controller,
              params: PdfViewerParams(
                onDocumentChanged: (document) {
                  if (document != null) _onDocumentReady();
                },
                // طبقة تمييز نتائج البحث فوق الصفحة المعروضة — خاصية
                // جاهزة من PdfTextSearcher نفسه (وليست دالة نكتبها).
                pagePaintCallbacks: [_textSearcher.pageTextMatchPaintCallback],
              ),
            );
          },
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (e, _) => Center(child: Text('تعذّر فتح الكتاب: $e')),
        ),
      ),
      bottomNavigationBar: _controlsVisible
          ? _ReaderBottomBar(controller: _controller)
          : null,
    );
  }

  Future<void> _addBookmark() async {
    if (!_controller.isReady) return;
    // pageNumber قابلة لـ null فعليًا في هذا الإصدار (أكّده flutter
    // analyze)، رغم أن isReady=true عادة يعني وجود صفحة حالية — نتحقق
    // بشكل صريح بدل استخدام '!' غير الآمنة.
    final currentPage = _controller.pageNumber;
    if (currentPage == null) return;

    // id=0 لأنه لا يُستخدَم فعليًا عند الإدخال (autoIncrement في قاعدة
    // البيانات هو من يولّد المعرّف الحقيقي، انظر BookmarksRepositoryImpl).
    await ref.read(bookmarksRepositoryProvider).addBookmark(
          BookmarkEntity(
            id: 0,
            bookId: widget.bookId,
            pageNumber: currentPage,
          ),
        );
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تمت إضافة العلامة المرجعية')),
      );
    }
  }

  void _showReaderSettingsSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (_) => const ReaderSettingsSheet(),
    );
  }
}

/// شريط سفلي بسيط لعرض رقم الصفحة الحالية والتنقل السريع
class _ReaderBottomBar extends StatelessWidget {
  final PdfViewerController controller;
  const _ReaderBottomBar({required this.controller});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: AnimatedBuilder(
          animation: controller,
          builder: (context, _) {
            final currentPage = controller.pageNumber;
            if (!controller.isReady || currentPage == null) {
              return const SizedBox(height: 32);
            }
            return Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                  icon: const Icon(Icons.chevron_right),
                  onPressed: () => controller.goToPage(
                    pageNumber: currentPage - 1,
                  ),
                ),
                Text('$currentPage / ${controller.pageCount}'),
                IconButton(
                  icon: const Icon(Icons.chevron_left),
                  onPressed: () => controller.goToPage(
                    pageNumber: currentPage + 1,
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
