import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

/// عتبة العرض التي دونها نعتبر الجهاز هاتفًا وفوقها جهازًا لوحيًا/شاشة كبيرة.
/// 600 هي القيمة القياسية المستخدمة في Material 3 Adaptive Guidelines.
const double tabletBreakpoint = 600;

class _NavDestination {
  final String label;
  final IconData icon;
  final IconData selectedIcon;
  final String path;

  const _NavDestination({
    required this.label,
    required this.icon,
    required this.selectedIcon,
    required this.path,
  });
}

const _destinations = [
  _NavDestination(
    label: 'الرئيسية',
    icon: Icons.home_outlined,
    selectedIcon: Icons.home,
    path: '/home',
  ),
  _NavDestination(
    label: 'الأقسام',
    icon: Icons.grid_view_outlined,
    selectedIcon: Icons.grid_view,
    path: '/sections',
  ),
  _NavDestination(
    label: 'البحث',
    icon: Icons.search_outlined,
    selectedIcon: Icons.search,
    path: '/search',
  ),
  _NavDestination(
    label: 'مكتبتي',
    icon: Icons.bookmark_outline,
    selectedIcon: Icons.bookmark,
    path: '/library',
  ),
  _NavDestination(
    label: 'الإعدادات',
    icon: Icons.settings_outlined,
    selectedIcon: Icons.settings,
    path: '/settings',
  ),
];

/// الحاوية الرئيسية للتنقل بين الشاشات الخمس، تتكيف تلقائيًا حسب عرض
/// الشاشة (بند سابع عشر + سادس عشر في الطلب: Responsive لكل الأجهزة).
class AdaptiveShell extends StatelessWidget {
  final Widget child;
  final String currentPath;

  const AdaptiveShell({
    super.key,
    required this.child,
    required this.currentPath,
  });

  int get _currentIndex {
    final index = _destinations.indexWhere((d) => currentPath.startsWith(d.path));
    return index == -1 ? 0 : index;
  }

  void _onSelect(BuildContext context, int index) {
    context.go(_destinations[index].path);
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;
    final isWide = width >= tabletBreakpoint;

    if (isWide) {
      return Scaffold(
        body: Row(
          children: [
            NavigationRail(
              selectedIndex: _currentIndex,
              onDestinationSelected: (i) => _onSelect(context, i),
              labelType: NavigationRailLabelType.all,
              destinations: _destinations
                  .map((d) => NavigationRailDestination(
                        icon: Icon(d.icon),
                        selectedIcon: Icon(d.selectedIcon),
                        label: Text(d.label),
                      ))
                  .toList(),
            ),
            const VerticalDivider(width: 1),
            Expanded(child: child),
          ],
        ),
      );
    }

    return Scaffold(
      body: child,
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (i) => _onSelect(context, i),
        destinations: _destinations
            .map((d) => NavigationDestination(
                  icon: Icon(d.icon),
                  selectedIcon: Icon(d.selectedIcon),
                  label: d.label,
                ))
            .toList(),
      ),
    );
  }
}
