import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/download/download_service.dart';
import '../providers/app_providers.dart';

String _formatBytes(int bytes) {
  if (bytes <= 0) return '0 كيلوبايت';
  const suffixes = ['بايت', 'كيلوبايت', 'ميجابايت', 'جيجابايت'];
  var value = bytes.toDouble();
  var i = 0;
  while (value >= 1024 && i < suffixes.length - 1) {
    value /= 1024;
    i++;
  }
  return '${value.toStringAsFixed(1)} ${suffixes[i]}';
}

/// محتوى "إدارة التنزيلات" (بند رابع عشر في الطلب): الكتب قيد التحميل +
/// الكتب المحمّلة + مساحة التخزين المستخدمة. بدون Scaffold خاص به لأنه
/// يُستخدم كتبويب داخل شاشة "مكتبتي" (التي تملك AppBar/TabBar خاصين بها).
class DownloadsScreen extends ConsumerWidget {
  const DownloadsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final activeTasks = ref.watch(downloadsNotifierProvider);
    final downloadedBooksAsync = ref.watch(downloadedBooksProvider);
    final storageUsedAsync = ref.watch(storageUsedProvider);

    final inProgressTasks = activeTasks.values
        .where((t) =>
            t.state == DownloadState.downloading || t.state == DownloadState.paused)
        .toList();

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: ListTile(
            leading: const Icon(Icons.sd_storage_outlined),
            title: const Text('المساحة المستخدمة'),
            trailing: storageUsedAsync.when(
              data: (bytes) => Text(_formatBytes(bytes)),
              loading: () => const SizedBox(
                width: 16,
                height: 16,
                child: CircularProgressIndicator(strokeWidth: 2),
              ),
              error: (_, __) => const Text('—'),
            ),
          ),
        ),
        const SizedBox(height: 16),

        if (inProgressTasks.isNotEmpty) ...[
          Text('قيد التحميل', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          ...inProgressTasks.map((task) => _DownloadTaskTile(task: task)),
          const SizedBox(height: 20),
        ],

        Text('الكتب المحمّلة', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        downloadedBooksAsync.when(
          data: (books) {
            if (books.isEmpty) {
              return const Padding(
                padding: EdgeInsets.symmetric(vertical: 24),
                child: Center(child: Text('لا توجد كتب محمّلة بعد')),
              );
            }
            return Column(
              children: books
                  .map((book) => Card(
                        child: ListTile(
                          leading: const Icon(Icons.picture_as_pdf_outlined),
                          title: Text(book.title,
                              maxLines: 1, overflow: TextOverflow.ellipsis),
                          subtitle: Text(
                            book.fileSizeBytes != null
                                ? _formatBytes(book.fileSizeBytes!)
                                : '',
                          ),
                          trailing: IconButton(
                            icon: const Icon(Icons.delete_outline),
                            onPressed: () => ref
                                .read(downloadsNotifierProvider.notifier)
                                .cancelAndDelete(book.id),
                          ),
                        ),
                      ))
                  .toList(),
            );
          },
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (e, _) => Text('حدث خطأ: $e'),
        ),
      ],
    );
  }
}

class _DownloadTaskTile extends ConsumerWidget {
  final DownloadTask task;
  const _DownloadTaskTile({required this.task});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final notifier = ref.read(downloadsNotifierProvider.notifier);
    final isPaused = task.state == DownloadState.paused;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(task.fileName,
                      maxLines: 1, overflow: TextOverflow.ellipsis),
                ),
                IconButton(
                  icon: Icon(isPaused ? Icons.play_arrow : Icons.pause),
                  onPressed: () {
                    if (isPaused) {
                      notifier.start(
                        bookId: task.bookId,
                        remoteUrl: task.remoteUrl,
                        fileName: task.fileName,
                      );
                    } else {
                      notifier.pause(task.bookId);
                    }
                  },
                ),
                IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: () => notifier.cancelAndDelete(task.bookId),
                ),
              ],
            ),
            const SizedBox(height: 6),
            LinearProgressIndicator(value: task.progress == 0 ? null : task.progress),
            const SizedBox(height: 4),
            Text(
              '${_formatBytes(task.receivedBytes)} / ${_formatBytes(task.totalBytes)}',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }
}
