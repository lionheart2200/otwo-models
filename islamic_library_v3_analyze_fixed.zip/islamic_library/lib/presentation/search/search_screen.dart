import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../app/theme/app_colors.dart';
import '../../core/search/models/search_result.dart';
import '../providers/app_providers.dart';

class SearchScreen extends ConsumerWidget {
  const SearchScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(searchNotifierProvider);
    final notifier = ref.read(searchNotifierProvider.notifier);

    return Scaffold(
      appBar: AppBar(
        title: const Text('البحث'),
        actions: [
          IconButton(
            icon: const Icon(Icons.tune),
            tooltip: 'فلاتر البحث المتقدم',
            onPressed: () => showModalBottomSheet(
              context: context,
              builder: (_) => const _AdvancedSearchFiltersSheet(),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              textDirection: TextDirection.rtl,
              autofocus: true,
              decoration: InputDecoration(
                hintText: 'ابحث في القرآن والحديث والفقه وجميع الكتب...',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: state.query.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.close),
                        onPressed: () => notifier.updateQuery(''),
                      )
                    : null,
              ),
              onChanged: notifier.updateQuery,
            ),
          ),

          _ActiveFiltersRow(scope: state.scope, filters: state.filters),

          if (!state.isLoading && state.query.trim().isNotEmpty && state.results.isNotEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: Align(
                alignment: Alignment.centerRight,
                child: Text(
                  '${state.results.length} نتيجة',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ),
            ),

          if (state.query.trim().isEmpty)
            const Expanded(child: _RecentSearches())
          else
            Expanded(
              child: state.isLoading
                  ? const Center(child: CircularProgressIndicator())
                  : state.results.isEmpty
                      ? const Center(child: Text('لا توجد نتائج'))
                      : ListView.builder(
                          padding: const EdgeInsets.symmetric(horizontal: 12),
                          itemCount: state.results.length,
                          itemBuilder: (context, i) =>
                              _SearchResultTile(result: state.results[i]),
                        ),
            ),
        ],
      ),
    );
  }
}

class _RecentSearches extends ConsumerWidget {
  const _RecentSearches();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final recentAsync = ref.watch(recentSearchesProvider);
    return recentAsync.when(
      data: (recent) {
        if (recent.isEmpty) {
          return const Center(child: Text('لا يوجد سجل بحث بعد'));
        }
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text('عمليات البحث الأخيرة', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: recent
                  .map((q) => ActionChip(
                        label: Text(q),
                        onPressed: () =>
                            ref.read(searchNotifierProvider.notifier).updateQuery(q),
                      ))
                  .toList(),
            ),
          ],
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (_, __) => const SizedBox.shrink(),
    );
  }
}

/// بطاقة نتيجة بحث واحدة: عنوان الكتاب، المؤلف، القسم، رقم الصفحة،
/// ومقتطف مع تمييز بصري للكلمة المطلوبة (بند ثالثًا في الطلب).
class _SearchResultTile extends StatelessWidget {
  final SearchResult result;
  const _SearchResultTile({required this.result});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: InkWell(
        onTap: () => context.push(
          '/reader/${result.bookId}'
          '?page=${result.pageNumber}'
          '&highlight=${Uri.encodeComponent(result.matchedQuery)}',
        ),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(result.bookTitle,
                  style: Theme.of(context).textTheme.titleMedium,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis),
              const SizedBox(height: 4),
              Text(
                [
                  if (result.authorName != null) result.authorName!,
                  result.sectionName,
                  'صفحة ${result.pageNumber}',
                ].join(' · '),
                style: Theme.of(context).textTheme.bodySmall,
              ),
              const SizedBox(height: 8),
              _HighlightedSnippet(snippet: result.snippet),
            ],
          ),
        ),
      ),
    );
  }
}

/// المقتطف يصل من FTS5 محاطًا بعلامتي ⟪ ⟫ حول موضع التطابق (انظر
/// دالة snippet() في search_engine.dart)، هذا الودجت يحوّلها لتمييز بصري.
class _HighlightedSnippet extends StatelessWidget {
  final String snippet;
  const _HighlightedSnippet({required this.snippet});

  @override
  Widget build(BuildContext context) {
    final spans = <TextSpan>[];
    final pattern = RegExp('⟪(.*?)⟫');
    var lastEnd = 0;

    for (final match in pattern.allMatches(snippet)) {
      if (match.start > lastEnd) {
        spans.add(TextSpan(text: snippet.substring(lastEnd, match.start)));
      }
      spans.add(TextSpan(
        text: match.group(1),
        style: const TextStyle(
          backgroundColor: AppColors.searchHighlight,
          fontWeight: FontWeight.w700,
        ),
      ));
      lastEnd = match.end;
    }
    if (lastEnd < snippet.length) {
      spans.add(TextSpan(text: snippet.substring(lastEnd)));
    }

    return RichText(
      textDirection: TextDirection.rtl,
      text: TextSpan(
        style: Theme.of(context).textTheme.bodyMedium,
        children: spans,
      ),
    );
  }
}

/// شريط صغير يعرض الفلاتر النشطة حاليًا (قسم/مؤلف محدد) مع إمكانية
/// إزالتها بسرعة، بدل فتح لوحة الفلاتر لكل تعديل بسيط.
class _ActiveFiltersRow extends ConsumerWidget {
  final SearchScope scope;
  final SearchFilters filters;
  const _ActiveFiltersRow({required this.scope, required this.filters});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final chips = <Widget>[];

    if (scope is SectionScope) {
      final sectionsAsync = ref.watch(allSectionsProvider);
      final sectionId = (scope as SectionScope).sectionId;
      final name = sectionsAsync.value
          ?.firstWhere((s) => s.id == sectionId, orElse: () => sectionsAsync.value!.first)
          .name;
      chips.add(_FilterChip(
        label: 'القسم: ${name ?? ''}',
        onRemoved: () =>
            ref.read(searchNotifierProvider.notifier).updateScope(const AllLibraryScope()),
      ));
    }

    if (filters.authorId != null) {
      final authorsAsync = ref.watch(allAuthorsProvider);
      final name = authorsAsync.value
          ?.firstWhere((a) => a.id == filters.authorId, orElse: () => authorsAsync.value!.first)
          .name;
      chips.add(_FilterChip(
        label: 'المؤلف: ${name ?? ''}',
        onRemoved: () => ref
            .read(searchNotifierProvider.notifier)
            .updateFilters(const SearchFilters()),
      ));
    }

    if (chips.isEmpty) return const SizedBox.shrink();

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Wrap(spacing: 8, children: chips),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final VoidCallback onRemoved;
  const _FilterChip({required this.label, required this.onRemoved});

  @override
  Widget build(BuildContext context) {
    return InputChip(label: Text(label), onDeleted: onRemoved);
  }
}

/// لوحة البحث المتقدم (بند ثامنًا في الطلب): اختيار قسم محدد ومؤلف محدد.
class _AdvancedSearchFiltersSheet extends ConsumerWidget {
  const _AdvancedSearchFiltersSheet();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sectionsAsync = ref.watch(allSectionsProvider);
    final authorsAsync = ref.watch(allAuthorsProvider);
    final state = ref.watch(searchNotifierProvider);
    final notifier = ref.read(searchNotifierProvider.notifier);

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('البحث المتقدم', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 16),

            Text('القسم', style: Theme.of(context).textTheme.bodySmall),
            const SizedBox(height: 6),
            sectionsAsync.when(
              data: (sections) => DropdownButtonFormField<int?>(
                initialValue: state.scope is SectionScope
                    ? (state.scope as SectionScope).sectionId
                    : null,
                items: [
                  const DropdownMenuItem(value: null, child: Text('كل المكتبة')),
                  ...sections.map(
                    (s) => DropdownMenuItem(value: s.id, child: Text(s.name)),
                  ),
                ],
                onChanged: (id) => notifier.updateScope(
                  id == null ? const AllLibraryScope() : SectionScope(id),
                ),
              ),
              loading: () => const LinearProgressIndicator(),
              error: (_, __) => const Text('تعذّر تحميل الأقسام'),
            ),

            const SizedBox(height: 16),
            Text('المؤلف', style: Theme.of(context).textTheme.bodySmall),
            const SizedBox(height: 6),
            authorsAsync.when(
              data: (authors) => DropdownButtonFormField<int?>(
                initialValue: state.filters.authorId,
                items: [
                  const DropdownMenuItem(value: null, child: Text('كل المؤلفين')),
                  ...authors.map(
                    (a) => DropdownMenuItem(value: a.id, child: Text(a.name)),
                  ),
                ],
                onChanged: (id) => notifier.updateFilters(
                  SearchFilters(authorId: id, sectionId: state.filters.sectionId),
                ),
              ),
              loading: () => const LinearProgressIndicator(),
              error: (_, __) => const Text('تعذّر تحميل المؤلفين'),
            ),
          ],
        ),
      ),
    );
  }
}
