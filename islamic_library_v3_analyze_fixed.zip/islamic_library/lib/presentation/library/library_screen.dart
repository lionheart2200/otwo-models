import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../providers/app_providers.dart';
import '../downloads/downloads_screen.dart';
import '../../widgets/book_card.dart';

class LibraryScreen extends ConsumerWidget {
  const LibraryScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('مكتبتي'),
          bottom: const TabBar(
            tabs: [
              Tab(text: 'المفضلة'),
              Tab(text: 'قيد القراءة'),
              Tab(text: 'التنزيلات'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            const _FavoritesTab(),
            const _ContinueReadingTab(),
            const DownloadsScreen(),
          ],
        ),
      ),
    );
  }
}

class _FavoritesTab extends ConsumerWidget {
  const _FavoritesTab();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final favoritesAsync = ref.watch(favoriteBooksProvider);
    return favoritesAsync.when(
      data: (books) {
        if (books.isEmpty) {
          return const Center(child: Text('لا توجد كتب مفضلة بعد'));
        }
        return _BooksGrid(books: books);
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => Center(child: Text('حدث خطأ: $e')),
    );
  }
}

class _ContinueReadingTab extends ConsumerWidget {
  const _ContinueReadingTab();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final booksAsync = ref.watch(continueReadingProvider);
    return booksAsync.when(
      data: (books) {
        if (books.isEmpty) {
          return const Center(child: Text('لم تبدأ قراءة أي كتاب بعد'));
        }
        return _BooksGrid(books: books);
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => Center(child: Text('حدث خطأ: $e')),
    );
  }
}


class _BooksGrid extends StatelessWidget {
  final List<dynamic> books;
  const _BooksGrid({required this.books});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      padding: const EdgeInsets.all(16),
      gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
        maxCrossAxisExtent: 140,
        mainAxisSpacing: 16,
        crossAxisSpacing: 16,
        childAspectRatio: 0.62,
      ),
      itemCount: books.length,
      itemBuilder: (context, i) => BookCard(book: books[i], width: double.infinity),
    );
  }
}
