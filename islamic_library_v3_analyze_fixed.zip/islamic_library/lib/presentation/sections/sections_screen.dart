import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../providers/app_providers.dart';

class SectionsScreen extends ConsumerWidget {
  const SectionsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sectionsAsync = ref.watch(allSectionsProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('الأقسام')),
      body: sectionsAsync.when(
        data: (sections) => GridView.builder(
          padding: const EdgeInsets.all(16),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 14,
            crossAxisSpacing: 14,
            childAspectRatio: 1.3,
          ),
          itemCount: sections.length,
          itemBuilder: (context, i) {
            final section = sections[i];
            return Card(
              child: InkWell(
                onTap: () => context.push('/sections/${section.id}', extra: section.name),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Icon(
                        Icons.menu_book_outlined,
                        color: Theme.of(context).colorScheme.primary,
                        size: 28,
                      ),
                      const SizedBox(height: 8),
                      Text(section.name,
                          style: Theme.of(context).textTheme.titleMedium),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('حدث خطأ: $e')),
      ),
    );
  }
}

/// شاشة تصفّح محتويات قسم أو مجلد (تُستدعى تكراريًا لأي عمق من المجلدات
/// عبر تمرير folderId المختلف في كل مرة — تحقيقًا لبند "عدد غير محدود
/// من المستويات").
class FolderBrowserScreen extends ConsumerWidget {
  final int sectionId;
  final int? folderId;
  final String title;

  const FolderBrowserScreen({
    super.key,
    required this.sectionId,
    required this.title,
    this.folderId,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final key = (sectionId: sectionId, folderId: folderId);
    final contentsAsync = ref.watch(folderContentsProvider(key));

    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: contentsAsync.when(
        data: (contents) {
          if (contents.folders.isEmpty && contents.books.isEmpty) {
            return const Center(child: Text('لا يوجد محتوى بعد'));
          }
          return ListView(
            children: [
              ...contents.folders.map((folder) => ListTile(
                    leading: const Icon(Icons.folder_outlined),
                    title: Text(folder.name),
                    trailing: const Icon(Icons.chevron_left),
                    onTap: () => context.push(
                      '/sections/$sectionId/folder/${folder.id}',
                      extra: folder.name,
                    ),
                  )),
              ...contents.books.map((book) => ListTile(
                    leading: const Icon(Icons.picture_as_pdf_outlined),
                    title: Text(book.title),
                    subtitle: book.author != null ? Text(book.author!.name) : null,
                    onTap: () => context.push('/book/${book.id}'),
                  )),
            ],
          );
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('حدث خطأ: $e')),
      ),
    );
  }
}
