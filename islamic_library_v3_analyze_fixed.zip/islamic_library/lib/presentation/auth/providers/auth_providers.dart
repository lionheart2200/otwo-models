import 'package:flutter_riverpod/flutter_riverpod.dart';
// StateNotifier/StateNotifierProvider انتقلا إلى هذا الملف في Riverpod 3.x
// (لم يعودا جزءًا من flutter_riverpod.dart الأساسي).
import 'package:flutter_riverpod/legacy.dart';

import '../../../core/admin/admin_auth_service.dart';

final adminAuthServiceProvider = Provider<AdminAuthService>((ref) {
  return AdminAuthService();
});

class AdminSessionState {
  final bool isLoggedIn;
  final bool isAdmin; // دائمًا true إذا isLoggedIn=true، لأن هذا تطبيق أدمن واحد فقط
  final bool isCheckingSession;

  const AdminSessionState({
    this.isLoggedIn = false,
    this.isAdmin = false,
    this.isCheckingSession = true,
  });

  AdminSessionState copyWith({
    bool? isLoggedIn,
    bool? isAdmin,
    bool? isCheckingSession,
  }) {
    return AdminSessionState(
      isLoggedIn: isLoggedIn ?? this.isLoggedIn,
      isAdmin: isAdmin ?? this.isAdmin,
      isCheckingSession: isCheckingSession ?? this.isCheckingSession,
    );
  }
}

class AdminSessionNotifier extends StateNotifier<AdminSessionState> {
  final AdminAuthService _service;

  AdminSessionNotifier(this._service) : super(const AdminSessionState()) {
    _restore();
  }

  Future<void> _restore() async {
    final loggedIn = await _service.restoreSession();
    state = AdminSessionState(
      isLoggedIn: loggedIn,
      isAdmin: loggedIn,
      isCheckingSession: false,
    );
  }

  Future<LoginResult> login(String email, String password) async {
    final result = await _service.login(email: email, password: password);
    if (result == LoginResult.success) {
      state = state.copyWith(isLoggedIn: true, isAdmin: true);
    }
    return result;
  }

  Future<void> logout() async {
    await _service.logout();
    state = state.copyWith(isLoggedIn: false, isAdmin: false);
  }
}

final adminSessionProvider =
    StateNotifierProvider<AdminSessionNotifier, AdminSessionState>((ref) {
  return AdminSessionNotifier(ref.watch(adminAuthServiceProvider));
});
