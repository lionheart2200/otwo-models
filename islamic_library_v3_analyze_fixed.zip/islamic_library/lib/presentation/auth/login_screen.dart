import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/admin/admin_auth_service.dart';
import 'providers/auth_providers.dart';

/// شاشة تسجيل دخول عامة الشكل (لا تُفصح أنها "دخول أدمن" في واجهتها،
/// تمامًا كما طلبت: موجودة لمن أراد استخدامها، ومن لم يسجّل دخول يرى
/// المحتوى كاملًا دون أي قيد). عمليًا حاليًا تمنح صلاحية فقط لبريد
/// الأدمن المحدد في AdminAuthService؛ أي بريد آخر لا يملك حسابًا هنا
/// لأنه لا يوجد نظام حسابات عام محليًا بعد (البند الحادي عشر من طلبك
/// الأصلي — المزامنة بين الأجهزة — يحتاج خادمًا حقيقيًا لاحقًا).
class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});

  @override
  ConsumerState<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends ConsumerState<LoginScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _isSubmitting = false;
  String? _errorText;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() {
      _isSubmitting = true;
      _errorText = null;
    });

    final result = await ref.read(adminSessionProvider.notifier).login(
          _emailController.text,
          _passwordController.text,
        );

    if (!mounted) return;
    setState(() => _isSubmitting = false);

    switch (result) {
      case LoginResult.success:
        context.pop();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تم تسجيل الدخول بنجاح')),
        );
      case LoginResult.wrongPassword:
        setState(() => _errorText = 'كلمة المرور غير صحيحة');
      case LoginResult.notAdminEmail:
        setState(() => _errorText = 'بيانات الدخول غير صحيحة');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تسجيل الدخول')),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _formKey,
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 400),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Icon(Icons.account_circle_outlined,
                      size: 64, color: Theme.of(context).colorScheme.primary),
                  const SizedBox(height: 16),
                  Text(
                    'تسجيل الدخول اختياري تمامًا — يمكنك تصفح المكتبة كاملة'
                    ' دون تسجيل الدخول.',
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                  const SizedBox(height: 24),

                  TextFormField(
                    controller: _emailController,
                    keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(labelText: 'البريد الإلكتروني'),
                    validator: (v) =>
                        (v == null || !v.contains('@')) ? 'أدخل بريدًا صحيحًا' : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _passwordController,
                    obscureText: true,
                    decoration: const InputDecoration(labelText: 'كلمة المرور'),
                    validator: (v) =>
                        (v == null || v.length < 4) ? 'كلمة المرور قصيرة جدًا' : null,
                  ),

                  if (_errorText != null) ...[
                    const SizedBox(height: 10),
                    Text(_errorText!,
                        style: TextStyle(color: Theme.of(context).colorScheme.error)),
                  ],

                  const SizedBox(height: 20),
                  FilledButton(
                    onPressed: _isSubmitting ? null : _submit,
                    child: _isSubmitting
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Text('دخول'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
