import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../providers/app_providers.dart';

class BookDetailsScreen extends ConsumerWidget {
  final int bookId;
  const BookDetailsScreen({super.key, required this.bookId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final bookAsync = ref.watch(bookByIdProvider(bookId));
    final favoritesRepo = ref.watch(favoritesRepositoryProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('تفاصيل الكتاب')),
      body: bookAsync.when(
        data: (book) {
          if (book == null) return const Center(child: Text('الكتاب غير موجود'));

          return ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Center(
                child: Container(
                  width: 140,
                  height: 190,
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primaryContainer,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: book.coverImagePath != null
                      ? ClipRRect(
                          borderRadius: BorderRadius.circular(14),
                          child: Image.asset(book.coverImagePath!, fit: BoxFit.cover),
                        )
                      : Icon(
                          Icons.menu_book_outlined,
                          size: 48,
                          color: Theme.of(context).colorScheme.onPrimaryContainer,
                        ),
                ),
              ),
              const SizedBox(height: 20),
              Text(book.title,
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.titleLarge),
              if (book.author != null) ...[
                const SizedBox(height: 6),
                Text(book.author!.name,
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.bodyMedium),
              ],
              const SizedBox(height: 20),

              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  FilledButton.icon(
                    onPressed: () => context.push('/reader/${book.id}'),
                    icon: const Icon(Icons.menu_book),
                    label: Text(book.isDownloaded ? 'قراءة' : 'تنزيل وقراءة'),
                  ),
                  const SizedBox(width: 12),
                  Consumer(
                    builder: (context, ref, _) {
                      final isFavAsync = ref.watch(isFavoriteProvider(book.id));
                      final isFav = isFavAsync.value ?? false;
                      return IconButton.filledTonal(
                        icon: Icon(isFav ? Icons.favorite : Icons.favorite_border),
                        onPressed: () async {
                          await favoritesRepo.toggleFavorite(book.id);
                          ref.invalidate(isFavoriteProvider(book.id));
                          ref.invalidate(favoriteBooksProvider);
                        },
                      );
                    },
                  ),
                ],
              ),

              const SizedBox(height: 24),
              if (book.description != null) ...[
                Text('نبذة عن الكتاب', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 8),
                Text(book.description!, style: Theme.of(context).textTheme.bodyMedium),
                const SizedBox(height: 20),
              ],

              _InfoRow(label: 'الناشر', value: book.publisherName),
              _InfoRow(label: 'الطبعة', value: book.edition),
              _InfoRow(
                label: 'عدد الصفحات',
                value: book.pageCount?.toString(),
              ),
              _InfoRow(
                label: 'حالة الفهرسة (قابلية البحث)',
                value: book.isSearchable ? 'مفهرس ✓' : 'غير مفهرس بعد',
              ),
            ],
          );
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('حدث خطأ: $e')),
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String? value;
  const _InfoRow({required this.label, this.value});

  @override
  Widget build(BuildContext context) {
    if (value == null || value!.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: Theme.of(context).textTheme.bodySmall),
          Text(value!, style: Theme.of(context).textTheme.bodyMedium),
        ],
      ),
    );
  }
}
