import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';
// StateNotifier/StateNotifierProvider انتقلا إلى هذا الملف في Riverpod 3.x
import 'package:flutter_riverpod/legacy.dart';

import '../../core/database/app_database.dart';
import '../../core/search/search_engine.dart';
import '../../core/search/models/search_result.dart';
import '../../core/pdf/pdf_indexing_service.dart';
import '../../core/download/download_service.dart';
import '../../core/storage/local_prefs_store.dart';
import '../../data/repositories/search_repository_impl.dart';
import '../../data/repositories/books_repository_impl.dart';
import '../../data/repositories/user_library_repositories_impl.dart';
import '../../data/mappers/entity_mappers.dart';
import '../../data/repositories/sections_folders_repository_impl.dart';
import '../../domain/entities/entities.dart';
import '../../domain/repositories/repositories.dart';

/// قاعدة البيانات: Instance واحد فقط طوال عمر التطبيق (keepAlive ضمنيًا
/// لأن Provider عادي بدون autoDispose يبقى حيًا).
final appDatabaseProvider = Provider<AppDatabase>((ref) {
  final db = AppDatabase();
  ref.onDispose(db.close);
  return db;
});

final localPrefsStoreProvider = Provider<LocalPrefsStore>((ref) => LocalPrefsStore());

final searchEngineProvider = Provider<SearchEngine>((ref) {
  return SearchEngine(ref.watch(appDatabaseProvider));
});

final pdfIndexingServiceProvider = Provider<PdfIndexingService>((ref) {
  final service = PdfIndexingService(ref.watch(appDatabaseProvider));
  ref.onDispose(service.dispose);
  return service;
});

final searchRepositoryProvider = Provider<SearchRepository>((ref) {
  return SearchRepositoryImpl(ref.watch(searchEngineProvider));
});

final booksRepositoryProvider = Provider<BooksRepository>((ref) {
  return BooksRepositoryImpl(ref.watch(appDatabaseProvider));
});

final readingProgressRepositoryProvider =
    Provider<ReadingProgressRepository>((ref) {
  return ReadingProgressRepositoryImpl(ref.watch(appDatabaseProvider));
});

final bookmarksRepositoryProvider = Provider<BookmarksRepository>((ref) {
  return BookmarksRepositoryImpl(ref.watch(appDatabaseProvider));
});

final favoritesRepositoryProvider = Provider<FavoritesRepository>((ref) {
  return FavoritesRepositoryImpl(ref.watch(appDatabaseProvider));
});

/// جلب كتاب واحد بمعرّفه — family حتى يُعاد استخدامه لأي bookId بدون
/// تكرار كتابة نفس منطق الجلب في كل شاشة تحتاجه (القارئ، تفاصيل الكتاب).
final bookByIdProvider =
    FutureProvider.family<BookEntity?, int>((ref, bookId) {
  return ref.watch(booksRepositoryProvider).getBookById(bookId);
});

final continueReadingProvider = FutureProvider<List<BookEntity>>((ref) {
  return ref.watch(booksRepositoryProvider).getContinueReading();
});

final recentlyAddedProvider = FutureProvider<List<BookEntity>>((ref) {
  return ref.watch(booksRepositoryProvider).getRecentlyAdded();
});

final mostReadProvider = FutureProvider<List<BookEntity>>((ref) {
  return ref.watch(booksRepositoryProvider).getMostRead();
});

final sectionsRepositoryProvider = Provider<SectionsRepository>((ref) {
  return SectionsRepositoryImpl(ref.watch(appDatabaseProvider));
});

final foldersRepositoryProvider = Provider<FoldersRepository>((ref) {
  return FoldersRepositoryImpl(ref.watch(appDatabaseProvider));
});

final allSectionsProvider = FutureProvider<List<SectionEntity>>((ref) {
  return ref.watch(sectionsRepositoryProvider).getAllSections();
});

/// قائمة كل المؤلفين — تُستخدم في فلتر "المؤلف" بشاشة البحث المتقدم.
final allAuthorsProvider = FutureProvider<List<AuthorEntity>>((ref) async {
  final db = ref.watch(appDatabaseProvider);
  final rows = await db.select(db.authors).get();
  return rows.map((r) => r.toEntity()).toList();
});

/// (sectionId, folderId?) -> محتويات المجلد الحالي
typedef FolderKey = ({int sectionId, int? folderId});

final folderContentsProvider =
    FutureProvider.family<({List<FolderEntity> folders, List<BookEntity> books}), FolderKey>(
        (ref, key) async {
  final folders = await ref
      .watch(foldersRepositoryProvider)
      .getFolders(sectionId: key.sectionId, parentFolderId: key.folderId);
  final books = await ref
      .watch(booksRepositoryProvider)
      .getBooksInSection(key.sectionId, folderId: key.folderId);
  return (folders: folders, books: books);
});

final favoriteBooksProvider = FutureProvider<List<BookEntity>>((ref) {
  return ref.watch(favoritesRepositoryProvider).getFavorites();
});

final isFavoriteProvider = FutureProvider.family<bool, int>((ref, bookId) {
  return ref.watch(favoritesRepositoryProvider).isFavorite(bookId);
});

final downloadServiceProvider = Provider<DownloadService>((ref) {
  final service = DownloadService();
  ref.onDispose(service.dispose);

  // بمجرد اكتمال أي تنزيل: نحدّث مسار الملف وحجمه في قاعدة البيانات،
  // ثم نضيف الكتاب فورًا لطابور الفهرسة — يصبح قابلًا للبحث تلقائيًا
  // دون أي تدخل يدوي من المستخدم أو المطوّر.
  service.updates.listen((task) async {
    if (task.state != DownloadState.completed) return;

    final localPath = await service.localFilePath(task.bookId, task.fileName);
    await ref.read(booksRepositoryProvider).updateBookFilePath(
          task.bookId,
          localPath,
          task.receivedBytes,
        );
    ref.read(pdfIndexingServiceProvider).enqueueBook(task.bookId);
  });

  return service;
});

/// حالة كل مهام التنزيل الحالية (Map بمعرّف الكتاب) — تُبنى من نفس
/// الـ Stream الذي يستهلكه downloadServiceProvider أعلاه، فلا يوجد أي
/// منطق تنزيل مكرر هنا، فقط عرض الحالة بشكل تفاعلي للواجهة.
class DownloadsNotifier extends StateNotifier<Map<int, DownloadTask>> {
  final DownloadService _service;
  late final StreamSubscription<DownloadTask> _sub;

  DownloadsNotifier(this._service) : super({}) {
    _sub = _service.updates.listen((task) {
      state = {...state, task.bookId: task};
    });
  }

  Future<void> start({
    required int bookId,
    required String remoteUrl,
    required String fileName,
  }) {
    return _service.download(bookId: bookId, remoteUrl: remoteUrl, fileName: fileName);
  }

  void pause(int bookId) => _service.pause(bookId);

  Future<void> cancelAndDelete(int bookId) async {
    await _service.cancelAndDelete(bookId);
    final updated = {...state}..remove(bookId);
    state = updated;
  }

  @override
  void dispose() {
    _sub.cancel();
    super.dispose();
  }
}

final downloadsNotifierProvider =
    StateNotifierProvider<DownloadsNotifier, Map<int, DownloadTask>>((ref) {
  return DownloadsNotifier(ref.watch(downloadServiceProvider));
});

final storageUsedProvider = FutureProvider<int>((ref) {
  ref.watch(downloadsNotifierProvider); // إعادة الحساب عند أي تغيير تنزيل
  return ref.watch(downloadServiceProvider).totalStorageUsedBytes();
});

final downloadedBooksProvider = FutureProvider<List<BookEntity>>((ref) {
  ref.watch(downloadsNotifierProvider);
  return ref.watch(booksRepositoryProvider).getAllDownloadedBooks();
});

/// اقتباس/فائدة اليوم (بند خامسًا + البند الإضافي 9 في الطلب): يُختار
/// بشكل شبه-ثابت لليوم الحالي (نفس الاقتباس طوال اليوم) من الاقتباسات
/// المحفوظة فعليًا في المكتبة، وليس نصًا مولَّدًا أو خارجيًا — هذا يحقق
/// شرط "الارتباط بمصادر موجودة في المكتبة" الذي طلبته صراحة.
final dailyQuoteProvider = FutureProvider<DailyQuote?>((ref) async {
  final db = ref.watch(appDatabaseProvider);
  final quotes = await db.select(db.savedQuotes).get();
  if (quotes.isEmpty) return null;

  final dayOfYear = DateTime.now()
      .difference(DateTime(DateTime.now().year, 1, 1))
      .inDays;
  final chosen = quotes[dayOfYear % quotes.length];

  final book = await ref.watch(booksRepositoryProvider).getBookById(chosen.bookId);
  return DailyQuote(
    text: chosen.quoteText,
    bookTitle: book?.title ?? '',
    pageNumber: chosen.pageNumber,
  );
});

class DailyQuote {
  final String text;
  final String bookTitle;
  final int pageNumber;
  const DailyQuote({required this.text, required this.bookTitle, required this.pageNumber});
}

/// حالة شاشة البحث الكاملة (نص الاستعلام + النطاق + النتائج + التحميل)
class SearchState {
  final String query;
  final SearchScope scope;
  final SearchFilters filters;
  final List<SearchResult> results;
  final bool isLoading;

  const SearchState({
    this.query = '',
    this.scope = const AllLibraryScope(),
    this.filters = const SearchFilters(),
    this.results = const [],
    this.isLoading = false,
  });

  SearchState copyWith({
    String? query,
    SearchScope? scope,
    SearchFilters? filters,
    List<SearchResult>? results,
    bool? isLoading,
  }) {
    return SearchState(
      query: query ?? this.query,
      scope: scope ?? this.scope,
      filters: filters ?? this.filters,
      results: results ?? this.results,
      isLoading: isLoading ?? this.isLoading,
    );
  }
}

/// Notifier مسؤول عن البحث الفوري مع Debounce حقيقي (300ms) — هذا هو
/// المكان الذي يمنع تنفيذ استعلام FTS مع كل ضغطة مفتاح، كما طلبت في
/// بند "البحث الفوري" مع "عدم تجميد الواجهة".
class SearchNotifier extends StateNotifier<SearchState> {
  final SearchRepository _repository;
  Timer? _debounceTimer;
  int _requestId = 0;

  SearchNotifier(this._repository) : super(const SearchState());

  void updateQuery(String query) {
    state = state.copyWith(query: query);
    _debounceTimer?.cancel();

    if (query.trim().isEmpty) {
      state = state.copyWith(results: [], isLoading: false);
      return;
    }

    state = state.copyWith(isLoading: true);
    _debounceTimer = Timer(const Duration(milliseconds: 300), _executeSearch);
  }

  void updateScope(SearchScope scope) {
    state = state.copyWith(scope: scope);
    if (state.query.trim().isNotEmpty) _executeSearch();
  }

  void updateFilters(SearchFilters filters) {
    state = state.copyWith(filters: filters);
    if (state.query.trim().isNotEmpty) _executeSearch();
  }

  Future<void> _executeSearch() async {
    final currentRequest = ++_requestId;
    final results = await _repository.search(
      query: state.query,
      scope: state.scope,
      filters: state.filters,
    );

    // تجاهل النتيجة إذا وصل طلب أحدث أثناء الانتظار (يمنع ظهور نتائج
    // قديمة متأخرة فوق نتائج أحدث بسبب اختلاف زمن تنفيذ الاستعلامات).
    if (currentRequest != _requestId) return;

    state = state.copyWith(results: results, isLoading: false);
    await _repository.saveSearch(state.query, _scopeLabel(state.scope), results.length);
  }

  String _scopeLabel(SearchScope scope) => switch (scope) {
        AllLibraryScope() => 'all',
        SectionScope(sectionId: final id) => 'section:$id',
        BookScope(bookId: final id) => 'book:$id',
      };

  @override
  void dispose() {
    _debounceTimer?.cancel();
    super.dispose();
  }
}

final searchNotifierProvider =
    StateNotifierProvider<SearchNotifier, SearchState>((ref) {
  return SearchNotifier(ref.watch(searchRepositoryProvider));
});

final recentSearchesProvider = FutureProvider<List<String>>((ref) {
  return ref.watch(searchRepositoryProvider).recentSearches();
});
