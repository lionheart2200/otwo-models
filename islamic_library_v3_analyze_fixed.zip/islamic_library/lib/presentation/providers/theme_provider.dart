import 'package:flutter/material.dart';
import 'package:flutter_riverpod/legacy.dart';

import '../../core/storage/local_prefs_store.dart';
import 'app_providers.dart' show localPrefsStoreProvider;

/// وضع السمة العام للتطبيق (Light / Dark / System) — بند سادس عشر في الطلب.
/// يُحفظ ويُستعاد تلقائيًا عبر LocalPrefsStore.
class ThemeModeNotifier extends StateNotifier<ThemeMode> {
  final LocalPrefsStore _store;

  ThemeModeNotifier(this._store) : super(ThemeMode.system) {
    _loadSaved();
  }

  Future<void> _loadSaved() async {
    final saved = await _store.getThemeMode();
    if (saved == null) return;
    state = ThemeMode.values.firstWhere(
      (m) => m.name == saved,
      orElse: () => ThemeMode.system,
    );
  }

  void setMode(ThemeMode mode) {
    state = mode;
    _store.setThemeMode(mode.name);
  }
}

final themeModeProvider =
    StateNotifierProvider<ThemeModeNotifier, ThemeMode>((ref) {
  return ThemeModeNotifier(ref.watch(localPrefsStoreProvider));
});
