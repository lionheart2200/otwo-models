/// كيانات الـ Domain نقية (Pure Dart) ولا تعرف شيئًا عن Drift أو SQLite
/// أو Flutter. طبقة الـ Data (Repositories) هي المسؤولة عن التحويل بين
/// صفوف قاعدة البيانات (Books, Sections...) وهذه الكيانات.
library;

class SectionEntity {
  final int id;
  final String name;
  final String? description;
  final String? iconName;
  final int sortOrder;
  final bool isActive;

  const SectionEntity({
    required this.id,
    required this.name,
    required this.sortOrder,
    required this.isActive,
    this.description,
    this.iconName,
  });
}

class FolderEntity {
  final int id;
  final int sectionId;
  final int? parentFolderId;
  final String name;
  final int sortOrder;

  const FolderEntity({
    required this.id,
    required this.sectionId,
    required this.name,
    required this.sortOrder,
    this.parentFolderId,
  });
}

class AuthorEntity {
  final int id;
  final String name;
  final String? bio;
  final String? deathYear;

  const AuthorEntity({
    required this.id,
    required this.name,
    this.bio,
    this.deathYear,
  });
}

enum BookIndexingState { notIndexed, indexing, indexed, needsOcr, failed }

class BookEntity {
  final int id;
  final int sectionId;
  final int? folderId;
  final String title;
  final String? description;
  final AuthorEntity? author;
  final String? publisherName;
  final String? edition;
  final String? localFilePath;
  final String? coverImagePath;
  final int? pageCount;
  final int? fileSizeBytes;
  final BookIndexingState indexingStatus;
  final bool isDownloaded;
  final int readCount;

  const BookEntity({
    required this.id,
    required this.sectionId,
    required this.title,
    required this.indexingStatus,
    required this.isDownloaded,
    required this.readCount,
    this.folderId,
    this.description,
    this.author,
    this.publisherName,
    this.edition,
    this.localFilePath,
    this.coverImagePath,
    this.pageCount,
    this.fileSizeBytes,
  });

  bool get isSearchable => indexingStatus == BookIndexingState.indexed;
}

class ReadingProgressEntity {
  final int bookId;
  final int lastPageRead;
  final double progressPercent;
  final int totalReadingSeconds;
  final DateTime lastReadAt;

  const ReadingProgressEntity({
    required this.bookId,
    required this.lastPageRead,
    required this.progressPercent,
    required this.totalReadingSeconds,
    required this.lastReadAt,
  });
}

class BookmarkEntity {
  final int id;
  final int bookId;
  final int pageNumber;
  final String? label;

  const BookmarkEntity({
    required this.id,
    required this.bookId,
    required this.pageNumber,
    this.label,
  });
}
