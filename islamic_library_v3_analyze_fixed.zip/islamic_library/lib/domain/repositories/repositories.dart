import '../entities/entities.dart';
import '../../core/search/models/search_result.dart';

/// كل واجهة هنا Pure Dart، والتنفيذ الفعلي (عبر Drift) يوجد في
/// lib/data/repositories/. هذا الفصل يسمح لاحقًا باستبدال قاعدة البيانات
/// أو حتى إضافة مصدر بيانات عن بُعد دون تغيير أي شيء في الـ Presentation.

abstract interface class SectionsRepository {
  Future<List<SectionEntity>> getAllSections();
  Future<SectionEntity?> getSectionById(int id);
  Future<int> createSection(SectionEntity section);
  Future<void> updateSection(SectionEntity section);
  Future<void> deleteSection(int id);
}

abstract interface class FoldersRepository {
  /// null parentFolderId => المجلدات الرئيسية داخل القسم مباشرة
  Future<List<FolderEntity>> getFolders({
    required int sectionId,
    int? parentFolderId,
  });
  Future<int> createFolder(FolderEntity folder);
  Future<void> deleteFolder(int id);
}

abstract interface class BooksRepository {
  Future<List<BookEntity>> getBooksInSection(int sectionId, {int? folderId});
  Future<BookEntity?> getBookById(int id);
  Future<List<BookEntity>> getRecentlyAdded({int limit = 10});
  Future<List<BookEntity>> getMostRead({int limit = 10});
  Future<List<BookEntity>> getContinueReading({int limit = 10});
  Future<List<BookEntity>> getAllDownloadedBooks();
  Future<int> addBook(BookEntity book);
  Future<void> updateBookFilePath(int bookId, String localPath, int fileSize);
  Future<void> deleteBook(int id);
  Future<void> incrementReadCount(int bookId);
}

abstract interface class SearchRepository {
  Future<List<SearchResult>> search({
    required String query,
    SearchScope scope,
    SearchFilters filters,
  });
  Future<int> countResults({required String query, SearchScope scope});
  Future<List<String>> recentSearches({int limit = 10});
  Future<void> saveSearch(String query, String scope, int resultsCount);
}

abstract interface class ReadingProgressRepository {
  Future<ReadingProgressEntity?> getProgress(int bookId);
  Future<void> updateProgress({
    required int bookId,
    required int lastPageRead,
    required double progressPercent,
    int additionalSeconds = 0,
  });
  Future<void> resetProgress(int bookId);
}

abstract interface class FavoritesRepository {
  Future<List<BookEntity>> getFavorites();
  Future<bool> isFavorite(int bookId);
  Future<void> toggleFavorite(int bookId);
}

abstract interface class BookmarksRepository {
  Future<List<BookmarkEntity>> getBookmarks(int bookId);
  Future<int> addBookmark(BookmarkEntity bookmark);
  Future<void> deleteBookmark(int id);
}
