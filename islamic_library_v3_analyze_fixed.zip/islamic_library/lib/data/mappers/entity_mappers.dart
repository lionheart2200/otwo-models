import '../../core/database/app_database.dart';
import '../../domain/entities/entities.dart';

/// كل التحويلات بين نماذج قاعدة البيانات (المولّدة من Drift) والكيانات
/// النقية في الـ Domain تمر من هنا فقط، حتى لا يتكرر منطق التحويل
/// في كل Repository على حدة.
extension SectionMapper on Section {
  SectionEntity toEntity() => SectionEntity(
        id: id,
        name: name,
        description: description,
        iconName: iconName,
        sortOrder: sortOrder,
        isActive: isActive,
      );
}

extension FolderMapper on Folder {
  FolderEntity toEntity() => FolderEntity(
        id: id,
        sectionId: sectionId,
        parentFolderId: parentFolderId,
        name: name,
        sortOrder: sortOrder,
      );
}

extension AuthorMapper on Author {
  AuthorEntity toEntity() =>
      AuthorEntity(id: id, name: name, bio: bio, deathYear: deathYear);
}

BookIndexingState _mapIndexingStatus(IndexingStatus status) {
  switch (status) {
    case IndexingStatus.notIndexed:
      return BookIndexingState.notIndexed;
    case IndexingStatus.indexing:
      return BookIndexingState.indexing;
    case IndexingStatus.indexed:
      return BookIndexingState.indexed;
    case IndexingStatus.needsOcr:
      return BookIndexingState.needsOcr;
    case IndexingStatus.failed:
      return BookIndexingState.failed;
  }
}

/// تحويل صف كتاب مع بيانات المؤلف (إن وُجدت عبر Join) إلى BookEntity
BookEntity mapBookRow(Book book, {Author? author, String? publisherName}) {
  return BookEntity(
    id: book.id,
    sectionId: book.sectionId,
    folderId: book.folderId,
    title: book.title,
    description: book.description,
    author: author?.toEntity(),
    publisherName: publisherName,
    edition: book.edition,
    localFilePath: book.localFilePath,
    coverImagePath: book.coverImagePath,
    pageCount: book.pageCount,
    fileSizeBytes: book.fileSizeBytes,
    indexingStatus: _mapIndexingStatus(book.indexingStatus),
    isDownloaded: book.isDownloaded,
    readCount: book.readCount,
  );
}
