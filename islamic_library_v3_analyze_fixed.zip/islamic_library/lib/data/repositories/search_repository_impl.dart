import '../../core/search/search_engine.dart';
import '../../core/search/models/search_result.dart';
import '../../domain/repositories/repositories.dart';

class SearchRepositoryImpl implements SearchRepository {
  final SearchEngine _engine;

  SearchRepositoryImpl(this._engine);

  @override
  Future<List<SearchResult>> search({
    required String query,
    SearchScope scope = const AllLibraryScope(),
    SearchFilters filters = const SearchFilters(),
  }) {
    return _engine.search(query: query, scope: scope, filters: filters);
  }

  @override
  Future<int> countResults({
    required String query,
    SearchScope scope = const AllLibraryScope(),
  }) {
    return _engine.countResults(query: query, scope: scope);
  }

  @override
  Future<List<String>> recentSearches({int limit = 10}) {
    return _engine.recentSearches(limit: limit);
  }

  @override
  Future<void> saveSearch(String query, String scope, int resultsCount) {
    return _engine.saveToHistory(query, scope, resultsCount);
  }
}
