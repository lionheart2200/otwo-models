import 'package:drift/drift.dart';

import '../../core/database/app_database.dart';
import '../../domain/entities/entities.dart';
import '../../domain/repositories/repositories.dart';
import '../mappers/entity_mappers.dart';

class ReadingProgressRepositoryImpl implements ReadingProgressRepository {
  final AppDatabase _db;
  ReadingProgressRepositoryImpl(this._db);

  @override
  Future<ReadingProgressEntity?> getProgress(int bookId) async {
    final row = await (_db.select(_db.readingProgress)
          ..where((t) => t.bookId.equals(bookId)))
        .getSingleOrNull();
    if (row == null) return null;
    return ReadingProgressEntity(
      bookId: row.bookId,
      lastPageRead: row.lastPageRead,
      progressPercent: row.progressPercent,
      totalReadingSeconds: row.totalReadingSeconds,
      lastReadAt: row.lastReadAt,
    );
  }

  @override
  Future<void> updateProgress({
    required int bookId,
    required int lastPageRead,
    required double progressPercent,
    int additionalSeconds = 0,
  }) async {
    final existing = await getProgress(bookId);
    final newSeconds =
        (existing?.totalReadingSeconds ?? 0) + additionalSeconds;

    await _db.into(_db.readingProgress).insertOnConflictUpdate(
          ReadingProgressCompanion(
            bookId: Value(bookId),
            lastPageRead: Value(lastPageRead),
            progressPercent: Value(progressPercent),
            totalReadingSeconds: Value(newSeconds),
            lastReadAt: Value(DateTime.now()),
          ),
        );
  }

  @override
  Future<void> resetProgress(int bookId) async {
    await (_db.delete(_db.readingProgress)
          ..where((t) => t.bookId.equals(bookId)))
        .go();
  }
}

class BookmarksRepositoryImpl implements BookmarksRepository {
  final AppDatabase _db;
  BookmarksRepositoryImpl(this._db);

  @override
  Future<List<BookmarkEntity>> getBookmarks(int bookId) async {
    final rows = await (_db.select(_db.bookmarks)
          ..where((t) => t.bookId.equals(bookId))
          ..orderBy([(t) => OrderingTerm.asc(t.pageNumber)]))
        .get();
    return rows
        .map((r) => BookmarkEntity(
              id: r.id,
              bookId: r.bookId,
              pageNumber: r.pageNumber,
              label: r.label,
            ))
        .toList();
  }

  @override
  Future<int> addBookmark(BookmarkEntity bookmark) {
    return _db.into(_db.bookmarks).insert(
          BookmarksCompanion.insert(
            bookId: bookmark.bookId,
            pageNumber: bookmark.pageNumber,
            label: Value(bookmark.label),
          ),
        );
  }

  @override
  Future<void> deleteBookmark(int id) {
    return (_db.delete(_db.bookmarks)..where((t) => t.id.equals(id))).go();
  }
}

class FavoritesRepositoryImpl implements FavoritesRepository {
  final AppDatabase _db;
  FavoritesRepositoryImpl(this._db);

  @override
  Future<List<BookEntity>> getFavorites() async {
    final query = _db.select(_db.favorites).join([
      innerJoin(_db.books, _db.books.id.equalsExp(_db.favorites.bookId)),
      leftOuterJoin(_db.authors, _db.authors.id.equalsExp(_db.books.authorId)),
    ])
      ..orderBy([OrderingTerm.desc(_db.favorites.addedAt)]);

    final rows = await query.get();
    return rows
        .map((row) => mapBookRow(
              row.readTable(_db.books),
              author: row.readTableOrNull(_db.authors),
            ))
        .toList();
  }

  @override
  Future<bool> isFavorite(int bookId) async {
    final row = await (_db.select(_db.favorites)
          ..where((t) => t.bookId.equals(bookId)))
        .getSingleOrNull();
    return row != null;
  }

  @override
  Future<void> toggleFavorite(int bookId) async {
    final isFav = await isFavorite(bookId);
    if (isFav) {
      await (_db.delete(_db.favorites)..where((t) => t.bookId.equals(bookId)))
          .go();
    } else {
      await _db.into(_db.favorites).insert(
            FavoritesCompanion.insert(bookId: bookId),
          );
    }
  }
}
