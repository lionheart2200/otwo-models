import 'package:drift/drift.dart';

import '../../core/database/app_database.dart';
import '../../domain/entities/entities.dart';
import '../../domain/repositories/repositories.dart';
import '../mappers/entity_mappers.dart';

class BooksRepositoryImpl implements BooksRepository {
  final AppDatabase _db;

  BooksRepositoryImpl(this._db);

  /// استعلام موحّد يضم بيانات المؤلف عبر Left Join، يُستخدم في كل دوال
  /// القراءة تفاديًا لتكرار منطق الـ Join.
  JoinedSelectStatement<HasResultSet, dynamic> _bookWithAuthorQuery() {
    return _db.select(_db.books).join([
      leftOuterJoin(_db.authors, _db.authors.id.equalsExp(_db.books.authorId)),
    ]);
  }

  List<BookEntity> _mapJoinedRows(List<TypedResult> rows) {
    return rows.map((row) {
      final book = row.readTable(_db.books);
      final author = row.readTableOrNull(_db.authors);
      return mapBookRow(book, author: author);
    }).toList();
  }

  @override
  Future<List<BookEntity>> getBooksInSection(int sectionId, {int? folderId}) async {
    final query = _bookWithAuthorQuery()
      ..where(_db.books.sectionId.equals(sectionId));
    if (folderId != null) {
      query.where(_db.books.folderId.equals(folderId));
    } else {
      query.where(_db.books.folderId.isNull());
    }
    query.orderBy([OrderingTerm.asc(_db.books.title)]);
    final rows = await query.get();
    return _mapJoinedRows(rows);
  }

  @override
  Future<BookEntity?> getBookById(int id) async {
    final query = _bookWithAuthorQuery()..where(_db.books.id.equals(id));
    final row = await query.getSingleOrNull();
    if (row == null) return null;
    return mapBookRow(
      row.readTable(_db.books),
      author: row.readTableOrNull(_db.authors),
    );
  }

  @override
  Future<List<BookEntity>> getRecentlyAdded({int limit = 10}) async {
    final query = _bookWithAuthorQuery()
      ..orderBy([OrderingTerm.desc(_db.books.addedAt)])
      ..limit(limit);
    return _mapJoinedRows(await query.get());
  }

  @override
  Future<List<BookEntity>> getMostRead({int limit = 10}) async {
    final query = _bookWithAuthorQuery()
      ..orderBy([OrderingTerm.desc(_db.books.readCount)])
      ..limit(limit);
    return _mapJoinedRows(await query.get());
  }

  @override
  Future<List<BookEntity>> getContinueReading({int limit = 10}) async {
    final query = _db.select(_db.books).join([
      innerJoin(
        _db.readingProgress,
        _db.readingProgress.bookId.equalsExp(_db.books.id),
      ),
      leftOuterJoin(
        _db.authors,
        _db.authors.id.equalsExp(_db.books.authorId),
      ),
    ])
      ..orderBy([OrderingTerm.desc(_db.readingProgress.lastReadAt)])
      ..limit(limit);

    final rows = await query.get();
    return _mapJoinedRows(rows);
  }

  @override
  Future<List<BookEntity>> getAllDownloadedBooks() async {
    final query = _bookWithAuthorQuery()
      ..where(_db.books.isDownloaded.equals(true))
      ..orderBy([OrderingTerm.desc(_db.books.addedAt)]);
    return _mapJoinedRows(await query.get());
  }

  @override
  Future<int> addBook(BookEntity book) {
    return _db.into(_db.books).insert(
          BooksCompanion.insert(
            sectionId: book.sectionId,
            title: book.title,
            folderId: Value(book.folderId),
            description: Value(book.description),
            localFilePath: Value(book.localFilePath),
          ),
        );
  }

  @override
  Future<void> updateBookFilePath(int bookId, String localPath, int fileSize) {
    return (_db.update(_db.books)..where((b) => b.id.equals(bookId))).write(
      BooksCompanion(
        localFilePath: Value(localPath),
        fileSizeBytes: Value(fileSize),
        isDownloaded: const Value(true),
      ),
    );
  }

  @override
  Future<void> deleteBook(int id) {
    return (_db.delete(_db.books)..where((b) => b.id.equals(id))).go();
  }

  @override
  Future<void> incrementReadCount(int bookId) async {
    await _db.customStatement(
      'UPDATE books SET read_count = read_count + 1 WHERE id = ?',
      [bookId],
    );
  }
}
