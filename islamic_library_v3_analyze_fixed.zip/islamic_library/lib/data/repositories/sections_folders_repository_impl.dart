import 'package:drift/drift.dart';

import '../../core/database/app_database.dart';
import '../../domain/entities/entities.dart';
import '../../domain/repositories/repositories.dart';
import '../mappers/entity_mappers.dart';

class SectionsRepositoryImpl implements SectionsRepository {
  final AppDatabase _db;
  SectionsRepositoryImpl(this._db);

  @override
  Future<List<SectionEntity>> getAllSections() async {
    final rows = await (_db.select(_db.sections)
          ..where((t) => t.isActive.equals(true))
          ..orderBy([(t) => OrderingTerm.asc(t.sortOrder)]))
        .get();
    return rows.map((r) => r.toEntity()).toList();
  }

  @override
  Future<SectionEntity?> getSectionById(int id) async {
    final row = await (_db.select(_db.sections)..where((t) => t.id.equals(id)))
        .getSingleOrNull();
    return row?.toEntity();
  }

  @override
  Future<int> createSection(SectionEntity section) {
    return _db.into(_db.sections).insert(
          SectionsCompanion.insert(
            name: section.name,
            description: Value(section.description),
            iconName: Value(section.iconName),
            sortOrder: Value(section.sortOrder),
          ),
        );
  }

  @override
  Future<void> updateSection(SectionEntity section) {
    return (_db.update(_db.sections)..where((t) => t.id.equals(section.id))).write(
      SectionsCompanion(
        name: Value(section.name),
        description: Value(section.description),
        iconName: Value(section.iconName),
        sortOrder: Value(section.sortOrder),
        isActive: Value(section.isActive),
      ),
    );
  }

  @override
  Future<void> deleteSection(int id) {
    return (_db.delete(_db.sections)..where((t) => t.id.equals(id))).go();
  }
}

class FoldersRepositoryImpl implements FoldersRepository {
  final AppDatabase _db;
  FoldersRepositoryImpl(this._db);

  @override
  Future<List<FolderEntity>> getFolders({
    required int sectionId,
    int? parentFolderId,
  }) async {
    final query = _db.select(_db.folders)
      ..where((t) => t.sectionId.equals(sectionId))
      ..orderBy([(t) => OrderingTerm.asc(t.sortOrder)]);

    if (parentFolderId != null) {
      query.where((t) => t.parentFolderId.equals(parentFolderId));
    } else {
      query.where((t) => t.parentFolderId.isNull());
    }

    final rows = await query.get();
    return rows.map((r) => r.toEntity()).toList();
  }

  @override
  Future<int> createFolder(FolderEntity folder) {
    return _db.into(_db.folders).insert(
          FoldersCompanion.insert(
            sectionId: folder.sectionId,
            name: folder.name,
            parentFolderId: Value(folder.parentFolderId),
            sortOrder: Value(folder.sortOrder),
          ),
        );
  }

  @override
  Future<void> deleteFolder(int id) {
    return (_db.delete(_db.folders)..where((t) => t.id.equals(id))).go();
  }
}
